/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Product, StockMovement, Customer } from '../types';

export const initialProducts: Product[] = [
  { id: 'P-001', name: 'Endüstriyel Konnektör Tip A', sku: 'EK-A-5P', type: 'Parça', supplier: 'Kablo A.Ş.', currentStock: 150, criticalStock: 50, unit: 'Adet', lastEntryDate: '2024-07-20', notes: 'Ağır sanayi koşullarına dayanıklı, 5 pinli konnektör.' },
  { id: 'P-002', name: 'Otomotiv Kablo Seti', sku: 'OKS-VW-G7', type: 'Parça', supplier: 'OtoKablo Ltd.', currentStock: 45, criticalStock: 20, unit: 'Adet', lastEntryDate: '2024-07-18', notes: 'VW Golf 7 için komple motor kablo seti.' },
  { id: 'P-003', name: 'NYY 3x2.5mm Güç Kablosu', sku: 'NYY-3X25', type: 'Top', supplier: 'Kablo A.Ş.', currentStock: 2500, criticalStock: 1000, unit: 'Metre', lastEntryDate: '2024-07-22', notes: 'Siyah, dış mekan kullanımına uygun, 100m top.' },
  { id: 'P-004', name: 'Kırmızı Sinyal Kablosu', sku: 'SK-RED-075', type: 'Top', supplier: 'PolKablo', currentStock: 0, criticalStock: 500, unit: 'Metre', lastEntryDate: '2024-06-15', notes: '0.75mm kesitli, esnek sinyal kablosu.' },
  { id: 'P-005', name: 'Bahar 2024 Renk Kartelası', sku: 'KARTELA-S24', type: 'Kartela', supplier: 'OtoKablo Ltd.', currentStock: 80, criticalStock: 25, unit: 'Adet', lastEntryDate: '2024-03-01', notes: 'Otomotiv sektörü için yeni sezon renkleri.' },
  { id: 'P-006', name: 'Kablo Ucu Yüksük Seti', sku: 'YUKSUK-SET-1200', type: 'Diğer', supplier: 'GlobalConnect', currentStock: 200, criticalStock: 50, unit: 'Paket', lastEntryDate: '2024-07-11', notes: '1200 parçalık karışık kablo ucu yüksük seti.' },
];

export const initialMovements: StockMovement[] = [
  { id: 'SM-001', date: '2024-07-22', productId: 'P-003', productName: 'NYY 3x2.5mm Güç Kablosu', type: 'Giriş', quantity: 3000, description: 'Tedarikçiden mal kabul', user: 'Admin' },
  { id: 'SM-002', date: '2024-07-21', productId: 'P-001', productName: 'Endüstriyel Konnektör Tip A', type: 'Çıkış', quantity: -50, description: 'S-24006 için sevk', user: 'Depo' },
  { id: 'SM-003', date: '2024-07-20', productId: 'P-001', productName: 'Endüstriyel Konnektör Tip A', type: 'Giriş', quantity: 200, description: 'Tedarikçiden mal kabul', user: 'Admin' },
  { id: 'SM-004', date: '2024-07-19', productId: 'P-004', productName: 'Kırmızı Sinyal Kablosu', type: 'Düzeltme', quantity: -25, description: 'Sayım farkı', user: 'Admin' },
];

export const initialOrders = [
    { id: 'S-24001', musteri: 'Tech Solutions A.Ş.', tedarikci: 'Kablo A.Ş.', urun: 'Endüstriyel Konnektör', seriNo: 'SN-A84B2', metre: 1200, parca: 2400, top: 12, toplamPLN: 48000.00, durum: 'gönderildi', siparisTarihi: '2024-07-15', teslimTarihi: '2024-07-25', aciklama: 'Acil sevkiyat gerekli.' },
    { id: 'S-24002', musteri: 'Oto Yedek Parça Ltd.', tedarikci: 'OtoKablo Ltd.', urun: 'Otomotiv Kablo Seti', seriNo: 'SN-C3F9A', metre: 5000, parca: 1000, top: 50, toplamPLN: 125000.00, durum: 'üretimde', siparisTarihi: '2024-07-18', teslimTarihi: '2024-08-05', aciklama: '' },
    { id: 'S-24003', musteri: 'Beyaz Eşya A.Ş.', tedarikci: 'Kablo A.Ş.', urun: 'Güç Kablosu', seriNo: 'SN-B1E0D', metre: 2500, parca: 2500, top: 25, toplamPLN: 62500.00, durum: 'gönderilecek', siparisTarihi: '2024-07-20', teslimTarihi: new Date(new Date().setDate(new Date().getDate() + 3)).toISOString().split('T')[0], aciklama: 'Özel paketleme.' },
    { id: 'S-24004', musteri: 'Jan Kowalski', tedarikci: 'PolKablo', urun: 'Sinyal Kablosu', seriNo: 'SN-D7A5C', metre: 300, parca: 600, top: 3, toplamPLN: 12000.00, durum: 'gönderildi', siparisTarihi: '2024-07-05', teslimTarihi: '2024-07-12', aciklama: '' },
    { id: 'S-24005', musteri: 'Global Exports', tedarikci: 'GlobalConnect', urun: 'Veri Kablosu Cat6', seriNo: 'SN-F2G7H', metre: 10000, parca: 2000, top: 100, toplamPLN: 250000.00, durum: 'üretimde', siparisTarihi: '2024-07-22', teslimTarihi: '2024-08-15', aciklama: 'Parti 1/3' },
    { id: 'S-24006', musteri: 'Tech Solutions A.Ş.', tedarikci: 'Kablo A.Ş.', urun: 'Endüstriyel Konnektör', seriNo: 'SN-H8I9J', metre: 1500, parca: 3000, top: 15, toplamPLN: 60000.00, durum: 'gönderilecek', siparisTarihi: '2024-07-25', teslimTarihi: new Date(new Date().setDate(new Date().getDate() + 5)).toISOString().split('T')[0], aciklama: '' },
    { id: 'S-24007', musteri: 'İnşaat A.Ş.', tedarikci: 'Enerji Kablo San.', urun: 'Enerji Kablosu', seriNo: 'SN-K1L2M', metre: 8000, parca: 800, top: 40, toplamPLN: 320000.00, durum: 'iptal', siparisTarihi: '2024-06-10', teslimTarihi: '2024-07-01', aciklama: 'Proje iptal oldu.' },
];

export const initialCustomers: Customer[] = [
    {
        id: 'C-001', firmaAdi: 'Tech Solutions A.Ş.', irtibatKisisi: 'Ahmet Yılmaz', musteriGrubu: 'Kurumsal', kisaKod: 'TSOL', kayitTarihi: '2023-01-15', kopya: false,
        vergiNumarasi: '1234567890', hesapNumarasi: 'PL123456789012345678901234', vergiDairesi: 'Maslak', faturaTipi: 'Normal',
        telefon1: '555-111-2233', telefon2: '', telefon3: '', email: 'ahmet.yilmaz@techsolutions.com', internetSitesi: 'techsolutions.com', sosyalMedya: '',
        faturaAdresi: { sokak: 'Büyükdere Cad. No:1', postaKodu: '34398', ilce: 'Sarıyer', sehir: 'İstanbul', ulke: 'Türkiye' },
        sevkiyatAdresi: { sokak: 'Büyükdere Cad. No:1', postaKodu: '34398', ilce: 'Sarıyer', sehir: 'İstanbul', ulke: 'Türkiye' },
        sevkiyatAdresiAyni: true,
        durum: 'Aktif', oncelik: 'Yüksek', hatGuzergah: 'Marmara-1', konumTuru: 'Merkez', dosya: 'TSOL-profile.pdf', etiketler: 'teknoloji, büyük müşteri', aciklama: 'Önemli müşteri, düzenli siparişleri var.',
        toplamHarcama: 150000, sonSiparisTarihi: '2024-07-15', senkDurumu: 'Senkronize'
    },
    {
        id: 'C-002', firmaAdi: 'Jan Kowalski', irtibatKisisi: 'Jan Kowalski', musteriGrubu: 'Bireysel', kisaKod: 'JKOW', kayitTarihi: '2024-06-20', kopya: false,
        vergiNumarasi: 'PL987654321', hesapNumarasi: '', vergiDairesi: 'Warszawa-Mokotów', faturaTipi: 'Faturasız',
        telefon1: '+48 500 100 200', telefon2: '', telefon3: '', email: 'jan.kowalski@example.pl', internetSitesi: '', sosyalMedya: '',
        faturaAdresi: { sokak: 'al. Jerozolimskie 123', postaKodu: '02-001', ilce: 'Ochota', sehir: 'Warszawa', ulke: 'Polonya' },
        sevkiyatAdresi: { sokak: 'ul. Marszałkowska 1', postaKodu: '00-624', ilce: 'Śródmieście', sehir: 'Warszawa', ulke: 'Polonya' },
        sevkiyatAdresiAyni: false,
        durum: 'Aktif', oncelik: 'Normal', hatGuzergah: '', konumTuru: '', dosya: '', etiketler: 'polonya, perakende', aciklama: '',
        toplamHarcama: 12000, sonSiparisTarihi: '2024-07-05', senkDurumu: 'Bekliyor'
    },
    {
        id: 'C-003', firmaAdi: 'Pasif Müşteri Ltd.', irtibatKisisi: 'Ayşe Kaya', musteriGrubu: 'Kurumsal', kisaKod: 'PASIF', kayitTarihi: '2022-03-10', kopya: false,
        vergiNumarasi: '0987654321', hesapNumarasi: '', vergiDairesi: 'Kadıköy', faturaTipi: 'Normal',
        telefon1: '555-444-5566', telefon2: '', telefon3: '', email: 'ayse.kaya@pasif.com', internetSitesi: '', sosyalMedya: '',
        faturaAdresi: { sokak: 'Bağdat Cad. No:100', postaKodu: '34728', ilce: 'Kadıköy', sehir: 'İstanbul', ulke: 'Türkiye' },
        sevkiyatAdresi: { sokak: 'Bağdat Cad. No:100', postaKodu: '34728', ilce: 'Kadıköy', sehir: 'İstanbul', ulke: 'Türkiye' },
        sevkiyatAdresiAyni: true,
        durum: 'Pasif', oncelik: 'Düşük', hatGuzergah: '', konumTuru: '', dosya: '', etiketler: '', aciklama: 'Uzun süredir sipariş vermiyor.',
        toplamHarcama: 25000, sonSiparisTarihi: '2023-01-20', senkDurumu: 'Senkronize'
    },
];
