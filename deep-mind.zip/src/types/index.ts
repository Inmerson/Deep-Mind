/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Define the available pages for type safety
export type Page =
  | 'anasayfa'
  | 'liste'
  | 'siparisler'
  | 'kargo'
  | 'stokYonetimi'
  | 'musteriler'
  | 'almanya'
  | 'turRehberi'
  | 'kasa'
  | 'mail'
  | 'copKutusu'
  | 'gecmis'
  | 'ayarlar';