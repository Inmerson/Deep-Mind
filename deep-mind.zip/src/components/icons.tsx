/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// A consistent set of professional, clean icons for the application.
// Style inspired by Lucide Icons (https://lucide.dev)

import React from 'react';

// Base props for all icons to ensure consistency
const iconProps = {
  width: "24",
  height: "24",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.5",
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

// --- Navigation Icons ---

export const HomeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...iconProps} {...props}>
    <path d="m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    <polyline points="9 22 9 12 15 12 15 22" />
  </svg>
);

export const ListChecksIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="m3 17 2 2 4-4" />
        <path d="m3 7 2 2 4-4" />
        <path d="M13 6h8" />
        <path d="M13 12h8" />
        <path d="M13 18h8" />
    </svg>
);

export const PackageIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M16.5 9.4a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0z" />
        <path d="M12 15H3.5a2.5 2.5 0 0 1-2.2-3.8l.1-.4.9-3.3c.2-.7.9-1.2 1.7-1.2H20c.8 0 1.5.5 1.7 1.2l.9 3.3.1.4a2.5 2.5 0 0 1-2.2 3.8H12z" />
        <path d="m3.1 9.4 17.8 0" />
    </svg>
);

export const ArchiveIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <rect width="20" height="5" x="2" y="3" rx="1" />
        <path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8" />
        <path d="M10 12h4" />
    </svg>
);

export const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
        <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
);

export const TruckIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M10 17h4V5H2v12h3" />
        <path d="M22 17h-6.11" />
        <path d="M14 5h4l4 4v8h-4" />
        <circle cx="7" cy="17" r="2" />
        <circle cx="18" cy="17" r="2" />
    </svg>
);

export const MapPinIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
        <circle cx="12" cy="10" r="3" />
    </svg>
);

export const CreditCardIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <rect width="20" height="14" x="2" y="5" rx="2" />
        <line x1="2" x2="22" y1="10" y2="10" />
    </svg>
);

export const MailIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...iconProps} {...props}>
    <rect width="20" height="16" x="2" y="4" rx="2" />
    <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
  </svg>
);

export const Trash2Icon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M3 6h18" />
        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6" />
        <path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
        <line x1="10" x2="10" y1="11" y2="17" />
        <line x1="14" x2="14" y1="11" y2="17" />
    </svg>
);

export const HistoryIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...iconProps} {...props}>
    <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
    <path d="M3 3v5h5" />
    <path d="M12 7v5l4 2" />
  </svg>
);

export const SettingsIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...iconProps} {...props}>
    <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 0 2l-.15.08a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l-.22-.38a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1 0-2l.15-.08a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);

// --- General UI Icons ---

export const MenuIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg {...iconProps} {...props}>
    <line x1="3" y1="12" x2="21" y2="12" />
    <line x1="3" y1="6" x2="21" y2="6" />
    <line x1="3" y1="18" x2="21" y2="18" />
  </svg>
);

export const SearchIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <circle cx="11" cy="11" r="8"></circle>
        <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
    </svg>
);

export const FilterIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon>
    </svg>
);

export const DownloadIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="7 10 12 15 17 10"></polyline>
        <line x1="12" y1="15" x2="12" y2="3"></line>
    </svg>
);

export const UploadIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
        <polyline points="17 8 12 3 7 8"></polyline>
        <line x1="12" y1="3" x2="12" y2="15"></line>
    </svg>
);

export const PlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <line x1="12" y1="5" x2="12" y2="19"></line>
        <line x1="5" y1="12" x2="19" y2="12"></line>
    </svg>
);

export const XIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
    </svg>
);

export const SendIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <path d="m22 2-7 20-4-9-9-4Z"/>
        <path d="M22 2 11 13"/>
    </svg>
);

export const MessageSquareIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
    </svg>
);

export const EditIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/>
    </svg>
);

export const FileTextIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} strokeWidth="2" {...props}>
        <path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"></path>
        <path d="M14 2v4a2 2 0 0 0 2 2h4"></path>
        <path d="M16 13H8"></path><path d="M16 17H8"></path>
        <path d="M10 9H8"></path>
    </svg>
);

export const LightningIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
      <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
    </svg>
);
  
export const BarChartIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <line x1="12" y1="20" x2="12" y2="10" />
        <line x1="18" y1="20" x2="18" y2="4" />
        <line x1="6" y1="20" x2="6" y2="16" />
    </svg>
);

export const SwapHorizontalIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <polyline points="16 3 21 3 21 8" />
        <line x1="4" y1="20" x2="21" y2="3" />
        <polyline points="8 21 3 21 3 16" />
        <line x1="20" y1="4" x2="3" y2="21" />
    </svg>
);
  
export const UserPlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <line x1="22" y1="11" x2="16" y2="11" />
      <line x1="19" y1="8" x2="19" y2="14" />
    </svg>
);
  
export const CalendarIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
      <path d="M8 2v4" />
      <path d="M16 2v4" />
      <rect width="18" height="18" x="3" y="4" rx="2" />
      <path d="M3 10h18" />
    </svg>
);

export const SquareIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
      <rect width="18" height="18" x="3" y="3" rx="2" />
    </svg>
);

export const GridIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <rect x="3" y="3" width="7" height="7"></rect>
        <rect x="14" y="3" width="7" height="7"></rect>
        <rect x="14" y="14" width="7" height="7"></rect>
        <rect x="3" y="14" width="7" height="7"></rect>
    </svg>
);

export const AlertTriangleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"></path>
        <line x1="12" y1="9" x2="12" y2="13"></line>
        <line x1="12" y1="17" x2="12.01" y2="17"></line>
    </svg>
);

export const BanIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <circle cx="12" cy="12" r="10"></circle>
        <path d="m4.9 4.9 14.2 14.2" />
    </svg>
);

export const LightbulbIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M15 14c.2-1 .7-1.7 1.5-2.5C17.7 10.5 18 9.3 18 8A6 6 0 0 0 6 8c0 1.3.3 2.5 1.5 3.5.7.8 1.3 1.5 1.5 2.5" />
        <path d="M9 18h6" />
        <path d="M10 22h4" />
    </svg>
);

export const SparklesIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="m12 3-1.9 4.2-4.2 1.9 4.2 1.9 1.9 4.2 1.9-4.2 4.2-1.9-4.2-1.9Z"/>
    </svg>
);

export const CheckCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
        <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
);
  
export const ListOrderedIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <line x1="10" x2="21" y1="6" y2="6" />
        <line x1="10" x2="21" y1="12" y2="12" />
        <line x1="10" x2="21" y1="18" y2="18" />
        <path d="M4 6h1v4" />
        <path d="M4 10h2" />
        <path d="M6 18H4c0-1 2-2 2-3s-1-1.5-2-1.5-2 .5-2 1.5c0 1.5 2 2.5 2 3.5" />
    </svg>
);

// --- Theme Icons ---
export const SunIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2" />
        <path d="M12 20v2" />
        <path d="m4.93 4.93 1.41 1.41" />
        <path d="m17.66 17.66 1.41 1.41" />
        <path d="M2 12h2" />
        <path d="M20 12h2" />
        <path d="m4.93 17.66 1.41-1.41" />
        <path d="m17.66 4.93 1.41-1.41" />
    </svg>
);

export const MoonIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg {...iconProps} {...props}>
        <path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z" />
    </svg>
);

// Deprecated icon names, mapped to new ones for backwards compatibility in case they are used elsewhere.
// Note: It's better to refactor usage to new names eventually.
export { ListChecksIcon as ListIcon }
export { PackageIcon as OrdersIcon }
export { ArchiveIcon as StockIcon }
export { UsersIcon as CustomersIcon }
export { MapPinIcon as LocationIcon }
export { CreditCardIcon as CashIcon }
export { Trash2Icon as TrashIcon }