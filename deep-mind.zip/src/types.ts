/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Define the available pages for type safety
export type Page =
  | 'anasayfa'
  | 'liste'
  | 'siparisler'
  | 'kargo'
  | 'stokYonetimi'
  | 'musteriler'
  | 'almanya'
  | 'turRehberi'
  | 'kasa'
  | 'mail'
  | 'copKutusu'
  | 'gecmis'
  | 'ayarlar';

export interface PageComponentProps {
  action?: string | null;
}

export type ProductType = 'Parça' | 'Top' | 'Kartela' | 'Diğer';
export type ProductUnit = 'Adet' | 'Metre' | 'KG' | 'Paket';

export interface Product {
  id: string;
  name: string;
  sku: string;
  type: ProductType;
  supplier: string;
  currentStock: number;
  criticalStock: number;
  unit: ProductUnit;
  lastEntryDate: string; // ISO date string
  notes: string;
}

export type StockMovementType = 'Giriş' | 'Çıkış' | 'Düzeltme' | 'Sipariş';

export interface StockMovement {
  id: string;
  date: string; // ISO date string
  productId: string;
  productName: string;
  type: StockMovementType;
  quantity: number;
  description: string;
  user: string;
}

// --- Order Types ---
export type OrderStatus = 'gönderildi' | 'gönderilecek' | 'üretimde' | 'iptal';

export interface Order {
  id: string;
  musteri: string;
  urun: string;
  tedarikci: string;
  seriNo: string;
  metre: number;
  parca: number;
  top: number;
  toplamPLN: number;
  durum: OrderStatus;
  siparisTarihi: string;
  teslimTarihi: string;
  aciklama: string;
}

// --- Customer Types ---

export type CustomerStatus = 'Aktif' | 'Pasif' | 'Dondurulmuş';
export type InvoiceType = 'Faturasız' | 'Normal' | 'Proforma';

export interface Address {
    sokak: string;
    postaKodu: string;
    ilce: string;
    sehir: string;
    ulke: string;
}

export interface Customer {
    id: string;
    // Kimlik Bilgileri
    firmaAdi: string;
    irtibatKisisi: string;
    musteriGrubu: string;
    kisaKod: string;
    kayitTarihi: string; // ISO date
    kopya: boolean;
    // Finansal Bilgiler
    vergiNumarasi: string; // NIP
    hesapNumarasi: string;
    vergiDairesi: string;
    faturaTipi: InvoiceType;
    // İletişim Bilgileri
    telefon1: string;
    telefon2: string;
    telefon3: string;
    email: string;
    internetSitesi: string;
    sosyalMedya: string;
    // Adresler
    faturaAdresi: Address;
    sevkiyatAdresi: Address;
    sevkiyatAdresiAyni: boolean;
    // Operasyonel Bilgiler
    durum: CustomerStatus;
    oncelik: string;
    hatGuzergah: string;
    konumTuru: string;
    dosya: string;
    etiketler: string; // Comma separated
    aciklama: string;
    // Derived data from other systems, for display in table
    toplamHarcama: number;
    sonSiparisTarihi?: string; // ISO date
    senkDurumu: 'Senkronize' | 'Bekliyor' | 'Hata';
}