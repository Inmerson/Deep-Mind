/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, createContext } from 'react';
import Sidebar from './layout/Sidebar';
import { pageComponents } from './pages/index';
import { Page } from './types';
import ThemeToggleButton from './components/ThemeToggleButton';

type NavigationContextType = (page: Page, action?: string | null) => void;
export const NavigationContext = createContext<NavigationContextType>(() => {});

const App = () => {
  const [activePage, setActivePage] = useState<Page>('anasayfa');
  const [pageAction, setPageAction] = useState<string | null>(null);
  const [isSidebarCollapsed, setSidebarCollapsed] = useState(true);
  
  const ActivePageComponent = pageComponents[activePage];

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light' || savedTheme === 'dark') {
      return savedTheme;
    }
    return 'light';
  });

  useEffect(() => {
    if (theme === 'dark') {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prevTheme => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  const handleNavigation = (page: Page, action: string | null = null) => {
    if (page === activePage) {
      // If on the same page, just trigger the action
      setPageAction(action);
      setTimeout(() => setPageAction(null), 50); // Reset after consumption
    } else {
      // If changing pages, set action then navigate
      setPageAction(action);
      setActivePage(page);
    }
  };
  
  // Effect to reset action when page changes
  useEffect(() => {
    if (pageAction) {
      const timer = setTimeout(() => setPageAction(null), 500); // Give component time to react
      return () => clearTimeout(timer);
    }
  }, [activePage]);


  return (
    <>
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        isSidebarCollapsed={isSidebarCollapsed}
        setSidebarCollapsed={setSidebarCollapsed}
      />
      <main className="main-content">
        <ThemeToggleButton theme={theme} toggleTheme={toggleTheme} />
        <NavigationContext.Provider value={handleNavigation}>
           <ActivePageComponent action={pageAction} />
        </NavigationContext.Provider>
      </main>
    </>
  );
};

export default App;