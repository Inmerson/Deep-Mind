/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Page } from '../types';
import { pageNavItems } from '../config/navigation';
import { MenuIcon } from '../components/icons';

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
  isSidebarCollapsed: boolean;
  setSidebarCollapsed: (collapsed: boolean) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  activePage,
  setActivePage,
  isSidebarCollapsed,
  setSidebarCollapsed,
}) => {
  return (
    <aside
      className={`sidebar ${isSidebarCollapsed ? 'collapsed' : ''}`}
    >
      <button
        className="sidebar-toggle-btn"
        onClick={() => setSidebarCollapsed(!isSidebarCollapsed)}
        aria-label="Toggle navigation"
        aria-expanded={!isSidebarCollapsed}
        aria-controls="main-navigation"
      >
        <MenuIcon />
      </button>
      <nav id="main-navigation" aria-label="Main navigation">
        <ul>
          {pageNavItems.map(({ id, label, icon: Icon }) => (
            <li key={id}>
              <button
                className={activePage === id ? 'active' : ''}
                onClick={() => setActivePage(id)}
                aria-current={activePage === id ? 'page' : undefined}
                aria-label={label}
                title={label}
              >
                <Icon />
                <span className="nav-label">{label}</span>
              </button>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;