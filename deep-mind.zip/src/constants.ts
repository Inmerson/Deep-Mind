/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  CreditCardIcon,
  UsersIcon,
  HistoryIcon,
  HomeIcon,
  ListChecksIcon,
  MapPinIcon,
  MailIcon,
  PackageIcon,
  SettingsIcon,
  ArchiveIcon,
  Trash2Icon,
  TruckIcon,
} from './components/icons';
import { Page } from './types';

export const pageNavItems: {
  id: Page;
  label: string;
  icon: React.ComponentType;
}[] = [
  { id: 'anasayfa', label: 'Anasayfa', icon: HomeIcon },
  { id: 'liste', label: 'Liste', icon: ListChecksIcon },
  { id: 'siparisler', label: 'Siparişler', icon: PackageIcon },
  { id: 'stokYonetimi', label: 'Stok Yönetimi', icon: ArchiveIcon },
  { id: 'musteriler', label: 'Müşteriler', icon: UsersIcon },
  { id: 'almanya', label: 'Almanya', icon: TruckIcon },
  { id: 'turRehberi', label: 'Tur Rehberi', icon: MapPinIcon },
  { id: 'kasa', label: 'Kasa', icon: CreditCardIcon },
  { id: 'mail', label: 'Mail', icon: MailIcon },
  { id: 'copKutusu', label: 'Çöp Kutusu', icon: Trash2Icon },
  { id: 'gecmis', label: 'Geçmiş', icon: HistoryIcon },
  { id: 'ayarlar', label: 'Ayarlar', icon: SettingsIcon },
];
