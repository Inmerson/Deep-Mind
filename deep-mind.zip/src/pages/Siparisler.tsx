/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, FC, FormEvent, ChangeEvent, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { initialOrders } from '../data/mock';

import {
  ListOrderedIcon,
  TruckIcon,
  CheckCircleIcon,
  CashIcon,
  SearchIcon,
  FilterIcon,
  UploadIcon,
  DownloadIcon,
  PlusIcon,
  XIcon,
  SendIcon,
  MessageSquareIcon,
  EditIcon,
  TrashIcon,
  FileTextIcon,
} from '../components/icons';
import { Order, OrderStatus } from '../types';

// --- DATA & TYPES ---
export const orderStatuses: OrderStatus[] = ['gönderilecek', 'üretimde', 'gönderildi', 'iptal'];

// --- HELPER & GENERIC COMPONENTS ---
export const statusTextMap: Record<OrderStatus, string> = {
    gönderildi: 'Gönderildi',
    gönderilecek: 'Gönderilecek',
    üretimde: 'Üretimde',
    iptal: 'İptal',
};

const StatusBadge: FC<{ status: OrderStatus }> = ({ status }) => (
    <span className={`status-badge status-${status}`}>
        {statusTextMap[status]}
    </span>
);

const EmptyState: FC<{message: string}> = ({ message }) => (
    <div className="empty-state">{message}</div>
);

const DoughnutChart: FC<{ data: { label: string, value: number, color: string }[], totalValue: number }> = ({ data, totalValue }) => {
    const radius = 85;
    const circumference = 2 * Math.PI * radius;
    let accumulatedOffset = 0;

    return (
        <div>
            <div className="doughnut-chart-container">
                <svg width="200" height="200" viewBox="0 0 200 200" className="doughnut-chart">
                    <circle cx="100" cy="100" r={radius} fill="transparent" stroke={getComputedStyle(document.documentElement).getPropertyValue('--border-color')} strokeWidth="30" />
                    {data.map(({ value, color }, index) => {
                        const dashOffset = circumference - (value / totalValue) * circumference;
                        const rotation = (accumulatedOffset / totalValue) * 360;
                        accumulatedOffset += value;
                        return (
                            <circle
                                key={index}
                                className="chart-segment"
                                cx="100" cy="100" r={radius}
                                stroke={color}
                                strokeDasharray={circumference}
                                strokeDashoffset={dashOffset}
                                style={{ transform: `rotate(${rotation}deg)`, transformOrigin: '50% 50%' }}
                            />
                        );
                    })}
                </svg>
                <div className="doughnut-chart-text">
                    <div className="chart-text-value">{totalValue}</div>
                    <div className="chart-text-label">Toplam Sipariş</div>
                </div>
            </div>
            <ul className="chart-legend">
                {data.map(({ label, color, value }) => (
                    <li key={label} className="legend-item">
                        <span className="legend-color-box" style={{ backgroundColor: color }}></span>
                        {label} ({value})
                    </li>
                ))}
            </ul>
        </div>
    );
};


// --- TABS ---

const GenelBakisTab: FC<{ orders: Order[] }> = ({ orders }) => {
    const summary = useMemo(() => {
        const totalSiparis = orders.length;
        const gonderilecek = orders.filter(o => o.durum === 'gönderilecek').length;
        const gonderildi = orders.filter(o => o.durum === 'gönderildi').length;
        const toplamTutar = orders.reduce((acc, o) => acc + o.toplamPLN, 0);
        return { totalSiparis, gonderilecek, gonderildi, toplamTutar };
    }, [orders]);

    const statusChartData = useMemo(() => {
        const statusCounts = orders.reduce((acc, order) => {
            acc[order.durum] = (acc[order.durum] || 0) + 1;
            return acc;
        }, {} as Record<OrderStatus, number>);

        const colors = {
            gönderildi: '#28a745',
            gönderilecek: '#ffc107',
            üretimde: '#17a2b8',
            iptal: '#6c757d',
        };
        
        return orderStatuses.filter(status => statusCounts[status] > 0).map(status => ({
            label: statusTextMap[status],
            value: statusCounts[status],
            color: colors[status],
        }));
    }, [orders]);

    const upcomingDeliveries = useMemo(() => {
        const today = new Date();
        const next7Days = new Date(new Date().setDate(today.getDate() + 7));
        return orders
            .filter(o => o.durum !== 'gönderildi' && o.durum !== 'iptal' && new Date(o.teslimTarihi) <= next7Days && new Date(o.teslimTarihi) >= new Date())
            .sort((a, b) => new Date(a.teslimTarihi).getTime() - new Date(b.teslimTarihi).getTime());
    }, [orders]);

    const StatCard: FC<{icon: React.ReactNode, title: string, value: string | number, iconBg: string, iconColor: string}> = ({icon, title, value, iconBg, iconColor}) => (
        <div className="card stat-card">
             <div className="stat-card-icon-wrapper" style={{'--icon-bg': iconBg, '--icon-color': iconColor} as React.CSSProperties} >
                {icon}
            </div>
            <div className="stat-card-info">
                <span className="stat-card-title">{title}</span>
                <div className="stat-card-value">{value}</div>
            </div>
        </div>
    );

    return (
        <div className="overview-grid">
            <div className="content-section" style={{ gridColumn: '1 / -1' }}>
                 <div className="card-grid">
                    <StatCard icon={<ListOrderedIcon />} title="Toplam Sipariş" value={summary.totalSiparis} iconBg="rgba(23, 162, 184, 0.1)" iconColor="var(--info-color)" />
                    <StatCard icon={<TruckIcon />} title="Gönderilecek" value={summary.gonderilecek} iconBg="rgba(255, 193, 7, 0.1)" iconColor="var(--warning-color)" />
                    <StatCard icon={<CheckCircleIcon />} title="Gönderildi" value={summary.gonderildi} iconBg="rgba(40, 167, 69, 0.1)" iconColor="var(--success-color)" />
                    <StatCard icon={<CashIcon />} title="Toplam Tutar" value={summary.toplamTutar.toLocaleString('tr-TR', { style: 'currency', currency: 'PLN', minimumFractionDigits: 0 })} iconBg="rgba(52, 58, 64, 0.1)" iconColor="var(--accent-color)" />
                </div>
            </div>
            <div className="content-section">
                <h2>Sipariş Durumları</h2>
                 {orders.length > 0 ? (
                    <DoughnutChart data={statusChartData} totalValue={orders.length} />
                ) : (
                    <EmptyState message="Grafik için veri yok." />
                )}
            </div>
            <div className="content-section">
                <h2>Yaklaşan Teslimatlar (7 Gün)</h2>
                {upcomingDeliveries.length > 0 ? (
                    <div className="delivery-list">
                        {upcomingDeliveries.map(order => (
                            <div key={order.id} className="delivery-item">
                                <div className="delivery-item-info">
                                    <strong>{order.musteri}</strong>
                                    <span>{order.urun}</span>
                                </div>
                                <div className="delivery-item-date">
                                    {new Date(order.teslimTarihi).toLocaleDateString('tr-TR', { day: '2-digit', month: 'long' })}
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                     <EmptyState message="Yaklaşan teslimat bulunmuyor."/>
                )}
            </div>
        </div>
    );
};

const FilterModal: FC<{
    isOpen: boolean;
    onClose: () => void;
    onApply: (filters: OrderStatus[]) => void;
    onClear: () => void;
    currentFilters: OrderStatus[];
}> = ({ isOpen, onClose, onApply, onClear, currentFilters }) => {
    const [selectedStatuses, setSelectedStatuses] = useState<OrderStatus[]>(currentFilters);

    useEffect(() => {
        setSelectedStatuses(currentFilters);
    }, [currentFilters, isOpen]);

    if (!isOpen) return null;

    const handleToggleStatus = (status: OrderStatus) => {
        setSelectedStatuses(prev => 
            prev.includes(status) ? prev.filter(s => s !== status) : [...prev, status]
        );
    };

    const handleApply = () => {
        onApply(selectedStatuses);
        onClose();
    };

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()} style={{maxWidth: '400px'}}>
                 <div className="modal-header">
                    <h2>Filtrele</h2>
                    <button type="button" onClick={onClose} className="modal-close-btn" aria-label="Kapat"><XIcon /></button>
                </div>
                <div className="modal-body">
                    <div className="form-group">
                        <label>Sipariş Durumu</label>
                        <div style={{display: 'flex', flexDirection: 'column', gap: '12px', marginTop: '8px'}}>
                            {orderStatuses.map(status => (
                                <div key={status} style={{display: 'flex', alignItems: 'center'}}>
                                    <input
                                        type="checkbox"
                                        id={`filter-status-${status}`}
                                        checked={selectedStatuses.includes(status)}
                                        onChange={() => handleToggleStatus(status)}
                                        style={{width: 'auto', marginRight: '10px', cursor: 'pointer'}}
                                    />
                                    <label htmlFor={`filter-status-${status}`} style={{fontWeight: 'normal', cursor: 'pointer'}}>
                                        <StatusBadge status={status} />
                                    </label>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                 <div className="modal-footer">
                    <button type="button" className="btn" onClick={onClear}>Filtreleri Temizle</button>
                    <button type="button" className="btn btn-primary" onClick={handleApply}>Uygula</button>
                </div>
            </div>
        </div>
    );
};

// --- IMPORT & EXPORT UTILITIES ---
const parseCsv = (text: string): { headers: string[], data: Record<string, string>[] } => {
    const lines = text.trim().split(/\r?\n/);
    if (lines.length === 0) return { headers: [], data: [] };

    const splitCsvRow = (row: string): string[] => {
        const result: string[] = [];
        let current = '';
        let inQuotes = false;
        for (let i = 0; i < row.length; i++) {
            const char = row[i];
            if (char === '"') {
                if (inQuotes && row[i + 1] === '"') {
                    current += '"';
                    i++;
                } else {
                    inQuotes = !inQuotes;
                }
            } else if (char === ',' && !inQuotes) {
                result.push(current);
                current = '';
            } else {
                current += char;
            }
        }
        result.push(current);
        return result;
    };

    const headers = splitCsvRow(lines[0]).map(h => h.trim());
    const data = lines.slice(1).map(line => {
        const values = splitCsvRow(line);
        return headers.reduce((obj, header, index) => {
            obj[header] = values[index] ? values[index].trim() : '';
            return obj;
        }, {} as Record<string, string>);
    });

    return { headers, data };
};

type ImportPreview = {
    valid: Order[];
    invalid: { row: Record<string, string>; error: string; rowIndex: number }[];
};

const ImportPreviewModal: FC<{
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (newOrders: Order[]) => void;
    previewData: ImportPreview | null;
}> = ({ isOpen, onClose, onConfirm, previewData }) => {
    const [activeTab, setActiveTab] = useState<'valid' | 'invalid'>('valid');

    useEffect(() => {
        if(previewData) {
            setActiveTab(previewData.valid.length > 0 ? 'valid' : 'invalid');
        }
    }, [previewData]);

    if (!isOpen || !previewData) return null;

    const { valid, invalid } = previewData;

    return (
        <div className="modal-overlay" onClick={onClose}>
            <div className="modal-content" onClick={e => e.stopPropagation()} style={{ maxWidth: '900px' }}>
                <div className="modal-header">
                    <h2>İçeri Aktarma Önizlemesi</h2>
                    <button type="button" onClick={onClose} className="modal-close-btn" aria-label="Kapat"><XIcon /></button>
                </div>
                <div className="modal-body">
                    <div className="import-summary">
                        <p><span className="success-text">{valid.length}</span> satır başarıyla doğrulandı.</p>
                        <p><span className="error-text">{invalid.length}</span> satırda hata bulundu.</p>
                    </div>

                    <div className="tabs">
                        <button className={`tab-btn ${activeTab === 'valid' ? 'active' : ''}`} onClick={() => setActiveTab('valid')}>
                            İçeri Aktarılacaklar ({valid.length})
                        </button>
                        <button className={`tab-btn ${activeTab === 'invalid' ? 'active' : ''}`} onClick={() => setActiveTab('invalid')}>
                            Hatalı Satırlar ({invalid.length})
                        </button>
                    </div>
                    
                    <div className="tab-content">
                        {activeTab === 'valid' && (
                            valid.length > 0 ? (
                                <div className="data-table-container">
                                    <table className="data-table">
                                        <thead><tr><th>Müşteri</th><th>Ürün</th><th>Seri No</th><th>Teslim Tarihi</th><th>Toplam PLN</th></tr></thead>
                                        <tbody>
                                            {valid.map((order, i) => <tr key={i}><td>{order.musteri}</td><td>{order.urun}</td><td>{order.seriNo}</td><td>{order.teslimTarihi}</td><td>{order.toplamPLN}</td></tr>)}
                                        </tbody>
                                    </table>
                                </div>
                            ) : <EmptyState message="İçeri aktarılacak geçerli satır bulunamadı." />
                        )}
                        {activeTab === 'invalid' && (
                            invalid.length > 0 ? (
                                <div className="data-table-container">
                                    <table className="data-table">
                                        <thead><tr><th>Satır #</th><th>Hata Mesajı</th><th>Müşteri</th><th>Ürün</th><th>Teslim Tarihi</th></tr></thead>
                                        <tbody>
                                            {invalid.map(({ row, error, rowIndex }, i) => <tr key={i}><td className="error-cell">{rowIndex}</td><td className="error-cell">{error}</td><td>{row.musteri}</td><td>{row.urun}</td><td>{row.teslimTarihi}</td></tr>)}
                                        </tbody>
                                    </table>
                                </div>
                            ) : <EmptyState message="Hatalı satır bulunamadı." />
                        )}
                    </div>

                </div>
                <div className="modal-footer">
                    <button type="button" className="btn" onClick={onClose}>İptal</button>
                    <button type="button" className="btn btn-primary" onClick={() => onConfirm(valid)} disabled={valid.length === 0}>
                        {valid.length} Siparişi Onayla
                    </button>
                </div>
            </div>
        </div>
    )
}

const TumSiparislerTab: FC<{ orders: Order[]; setOrders: React.Dispatch<React.SetStateAction<Order[]>>; handleEdit: (order: Order | null) => void }> = ({ orders, setOrders, handleEdit }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 10;
    const importInputRef = useRef<HTMLInputElement>(null);

    const [isFilterModalOpen, setFilterModalOpen] = useState(false);
    const [activeStatusFilters, setActiveStatusFilters] = useState<OrderStatus[]>([]);
    
    const [importPreview, setImportPreview] = useState<ImportPreview | null>(null);

    const [sortColumn, setSortColumn] = useState<keyof Order>('siparisTarihi');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
    const [selectedRows, setSelectedRows] = useState(new Set<string>());

    const handleSort = (column: keyof Order) => {
        const isAsc = sortColumn === column && sortDirection === 'asc';
        setSortDirection(isAsc ? 'desc' : 'asc');
        setSortColumn(column);
    };

    const sortedAndFilteredOrders = useMemo(() => {
        let sortableItems = [...orders];

        sortableItems.sort((a, b) => {
            const aVal = a[sortColumn];
            const bVal = b[sortColumn];
            
            if (aVal === null || aVal === undefined) return 1;
            if (bVal === null || bVal === undefined) return -1;
            
            if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
            if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
            return 0;
        });

        return sortableItems
            .filter(order =>
                activeStatusFilters.length === 0 || activeStatusFilters.includes(order.durum as OrderStatus)
            )
            .filter(order =>
                order.musteri.toLowerCase().includes(searchTerm.toLowerCase()) ||
                order.urun.toLowerCase().includes(searchTerm.toLowerCase()) ||
                order.seriNo.toLowerCase().includes(searchTerm.toLowerCase()) ||
                (order.tedarikci && order.tedarikci.toLowerCase().includes(searchTerm.toLowerCase()))
            );
    }, [orders, searchTerm, activeStatusFilters, sortColumn, sortDirection]);

    const paginatedOrders = useMemo(() => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        return sortedAndFilteredOrders.slice(startIndex, startIndex + itemsPerPage);
    }, [sortedAndFilteredOrders, currentPage, itemsPerPage]);

    const totalPages = Math.ceil(sortedAndFilteredOrders.length / itemsPerPage);

    useEffect(() => {
        setSelectedRows(new Set());
    }, [paginatedOrders]);

    const handleSelectAll = (e: ChangeEvent<HTMLInputElement>) => {
        if (e.target.checked) {
            const allRowIds = paginatedOrders.map(o => o.id);
            setSelectedRows(new Set(allRowIds));
        } else {
            setSelectedRows(new Set());
        }
    };

    const handleSelectRow = (id: string) => {
        setSelectedRows(prev => {
            const newSelection = new Set(prev);
            if (newSelection.has(id)) {
                newSelection.delete(id);
            } else {
                newSelection.add(id);
            }
            return newSelection;
        });
    };
    
    const isAllSelectedOnPage = paginatedOrders.length > 0 && selectedRows.size === paginatedOrders.length;


    const handleDelete = (id: string) => {
        if(window.confirm("Bu siparişi silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.")) {
            setOrders(prev => prev.filter(order => order.id !== id));
        }
    }

    const handleApplyFilters = (filters: OrderStatus[]) => {
        setActiveStatusFilters(filters);
        setCurrentPage(1);
    };

    const handleClearFilters = () => {
        setActiveStatusFilters([]);
        setFilterModalOpen(false);
        setCurrentPage(1);
    }
    
    const escapeCsvCell = (cell: any): string => {
        if (cell === null || cell === undefined) return '';
        const strCell = String(cell);
        if (strCell.includes(',') || strCell.includes('"') || strCell.includes('\n')) {
            return `"${strCell.replace(/"/g, '""')}"`;
        }
        return strCell;
    };

    const handleExportCSV = () => {
        if (sortedAndFilteredOrders.length === 0) {
            alert("Dışa aktarılacak veri bulunmamaktadır.");
            return;
        }
        
        const headers: (keyof Order)[] = ['siparisTarihi', 'musteri', 'urun', 'tedarikci', 'seriNo', 'metre', 'parca', 'top', 'toplamPLN', 'durum', 'teslimTarihi', 'aciklama'];
        const displayHeaders = ['Tarih', 'Müşteri', 'Ürün', 'Tedarikçi', 'Seri No', 'Metre', 'Parça', 'Top', 'Toplam PLN', 'Durum', 'Teslim Tarihi', 'Açıklama'];
        
        const rows = sortedAndFilteredOrders.map(order => headers.map(header => escapeCsvCell(order[header])).join(','));
        const csvContent = [displayHeaders.join(','), ...rows].join('\n');
        
        const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", "siparisler.csv");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };

    const handleDownloadTemplate = () => {
        const headers: (keyof Order)[] = ['siparisTarihi', 'musteri', 'urun', 'tedarikci', 'seriNo', 'metre', 'parca', 'top', 'toplamPLN', 'durum', 'teslimTarihi', 'aciklama'];
        const csvContent = headers.join(',');
        const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", "siparis_sablonu.csv");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
    };


    const handleImport = (event: ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (e) => {
            const text = e.target?.result as string;
            if(!text) {
                alert("Dosya okunamadı veya boş.");
                return;
            }
            try {
                const { headers, data } = parseCsv(text);
                const requiredHeaders: (keyof Order)[] = ['musteri', 'urun', 'teslimTarihi'];
                
                for(const rh of requiredHeaders) {
                    if (!headers.includes(rh)) throw new Error(`CSV dosyasında zorunlu başlık bulunamadı: ${rh}`);
                }

                const validRows: Order[] = [];
                const invalidRows: { row: Record<string, string>, error: string, rowIndex: number }[] = [];

                data.forEach((row, index) => {
                    const rowIndex = index + 2; // +1 for header, +1 for 0-index
                    if (!row.musteri || !row.urun || !row.teslimTarihi) {
                        invalidRows.push({ row, rowIndex, error: "Eksik zorunlu alanlar (musteri, urun, teslimTarihi)." });
                        return;
                    }
                    if (isNaN(Date.parse(row.teslimTarihi))) {
                        invalidRows.push({ row, rowIndex, error: `Geçersiz teslim tarihi formatı: "${row.teslimTarihi}". YYYY-MM-DD kullanın.` });
                        return;
                    }
                     if (row.siparisTarihi && isNaN(Date.parse(row.siparisTarihi))) {
                        invalidRows.push({ row, rowIndex, error: `Geçersiz sipariş tarihi formatı: "${row.siparisTarihi}". YYYY-MM-DD kullanın.` });
                        return;
                    }
                    const newOrder: Order = {
                        id: `S-imp-${Date.now() + index}`,
                        musteri: row.musteri,
                        urun: row.urun,
                        tedarikci: row.tedarikci || '',
                        teslimTarihi: row.teslimTarihi,
                        seriNo: row.seriNo || '',
                        metre: Number(row.metre) || 0,
                        parca: Number(row.parca) || 0,
                        top: Number(row.top) || 0,
                        toplamPLN: Number(row.toplamPLN) || 0,
                        durum: orderStatuses.includes(row.durum as OrderStatus) ? row.durum as OrderStatus : 'gönderilecek',
                        siparisTarihi: row.siparisTarihi || new Date().toISOString().split('T')[0],
                        aciklama: row.aciklama || '',
                    };
                    validRows.push(newOrder);
                });

                setImportPreview({ valid: validRows, invalid: invalidRows });

            } catch (error) {
                alert(`CSV dosyası işlenirken bir hata oluştu: ${(error as Error).message}`);
            } finally {
                 if(event.target) event.target.value = '';
            }
        };
        reader.readAsText(file, "UTF-8");
    };

    const handleConfirmImport = (newOrders: Order[]) => {
        if(newOrders.length > 0) {
            setOrders(prev => [...newOrders, ...prev]);
        }
        setImportPreview(null); // Close modal
    };
    
    const SortIndicator: FC<{direction: 'asc' | 'desc'}> = ({direction}) => (
        <span style={{color: '#4285F4', paddingLeft: '4px', display: 'inline-block'}}>{direction === 'desc' ? '▼' : '▲'}</span>
    );

    return (
        <div>
            <div className="toolbar">
                <div className="search-box">
                    <SearchIcon />
                    <input type="text" placeholder="Müşteri, ürün, seri no veya tedarikçi ara..." value={searchTerm} onChange={e => {setSearchTerm(e.target.value); setCurrentPage(1);}}/>
                </div>
                <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <button className="btn" onClick={() => setFilterModalOpen(true)}><FilterIcon /> Filtrele</button>
                    <button className="btn" onClick={handleDownloadTemplate}><FileTextIcon /> Şablonu İndir</button>
                    <button className="btn" onClick={() => importInputRef.current?.click()}><UploadIcon /> İçeri Aktar</button>
                    <input type="file" ref={importInputRef} onChange={handleImport} accept=".csv" style={{display: 'none'}} />
                    <button className="btn" onClick={handleExportCSV}><DownloadIcon /> Dışa Aktar</button>
                    <button className="btn btn-primary" onClick={() => handleEdit(null)}><PlusIcon /> Yeni Sipariş</button>
                </div>
            </div>
            <div className="data-table-container">
                <table className="data-table">
                    <thead>
                        <tr>
                            <th><input type="checkbox" checked={isAllSelectedOnPage} onChange={handleSelectAll} aria-label="Select all orders on this page" /></th>
                            <th className="sortable" onClick={() => handleSort('siparisTarihi')}>Tarih {sortColumn === 'siparisTarihi' && <SortIndicator direction={sortDirection} />}</th>
                            <th>Müşteri</th>
                            <th>Ürün</th>
                            <th>Tedarikçi</th>
                            <th>Seri No</th>
                            <th>Metre</th>
                            <th>Parça</th>
                            <th>Top</th>
                            <th>Toplam PLN</th>
                            <th>Durum</th>
                            <th>Teslim Tarihi</th>
                            <th>Açıklama</th>
                            <th>Eylemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        {paginatedOrders.length > 0 ? paginatedOrders.map(order => (
                            <tr key={order.id} className={selectedRows.has(order.id) ? 'selected' : ''}>
                                <td><input type="checkbox" checked={selectedRows.has(order.id)} onChange={() => handleSelectRow(order.id)} aria-label={`Select order ${order.id}`} /></td>
                                <td>{new Date(order.siparisTarihi).toLocaleDateString('tr-TR')}</td>
                                <td>{order.musteri}</td>
                                <td>{order.urun}</td>
                                <td>{order.tedarikci}</td>
                                <td>{order.seriNo}</td>
                                <td>{order.metre.toLocaleString('tr-TR')}</td>
                                <td>{order.parca.toLocaleString('tr-TR')}</td>
                                <td>{order.top.toLocaleString('tr-TR')}</td>
                                <td>{order.toplamPLN.toLocaleString('tr-TR')}</td>
                                <td><StatusBadge status={order.durum as OrderStatus} /></td>
                                <td>{new Date(order.teslimTarihi).toLocaleDateString('tr-TR')}</td>
                                <td style={{whiteSpace: 'normal', maxWidth: '200px'}}>{order.aciklama}</td>
                                <td className="table-actions">
                                    <button title="Düzenle" onClick={() => handleEdit(order)}><EditIcon /></button>
                                    <button title="Sil" onClick={() => handleDelete(order.id)}><TrashIcon /></button>
                                </td>
                            </tr>
                        )) : (
                            <tr>
                                <td colSpan={14}><EmptyState message="Arama kriterlerinize uygun sipariş bulunamadı."/></td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>
             <div className="pagination">
                <span>{sortedAndFilteredOrders.length} sonuçtan {sortedAndFilteredOrders.length > 0 ? Math.min((currentPage - 1) * itemsPerPage + 1, sortedAndFilteredOrders.length) : 0}-{Math.min(currentPage * itemsPerPage, sortedAndFilteredOrders.length)} arası gösteriliyor</span>
                <div className="pagination-controls">
                    <button className="btn" onClick={() => setCurrentPage(p => p - 1)} disabled={currentPage === 1}>Önceki</button>
                    <button className="btn" onClick={() => setCurrentPage(p => p + 1)} disabled={currentPage >= totalPages}>Sonraki</button>
                </div>
            </div>
            <FilterModal 
                isOpen={isFilterModalOpen}
                onClose={() => setFilterModalOpen(false)}
                onApply={handleApplyFilters}
                onClear={handleClearFilters}
                currentFilters={activeStatusFilters}
            />
            <ImportPreviewModal
                isOpen={!!importPreview}
                onClose={() => setImportPreview(null)}
                onConfirm={handleConfirmImport}
                previewData={importPreview}
            />
        </div>
    );
};

const AnalizTab: FC<{orders: Order[]}> = ({ orders }) => {
    const [messages, setMessages] = useState<{ role: 'user' | 'ai'; text: string | React.ReactNode }[]>([
        { role: 'ai', text: "Merhaba! Güncel sipariş verileriniz hakkında sorular sorabilirsiniz. Başlamak için aşağıdaki önerilerden birini deneyin veya kendi sorunuzu yazın." }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY as string }), []);

    const handleSendMessage = async (promptText = input) => {
        if (!promptText.trim() || isLoading) return;

        setInput('');
        setMessages(prev => [...prev, { role: 'user', text: promptText }]);
        setIsLoading(true);
        
        // Add loading indicator immediately
        setTimeout(() => {
          setMessages(prev => [...prev, { role: 'ai', text: <div className="loading-dots"><span></span><span></span><span></span></div> }]);
        }, 100);

        try {
            const systemInstruction = "Sen bir sipariş yönetim sistemi için uzman bir veri analistisin. Sağlanan JSON verilerine dayanarak soruları yanıtla. Kısa, net ve profesyonel bir dille konuş. Yanıtlarını her zaman Türkçe ver. Sipariş durumu sorulduğunda şu terimleri kullan: 'gönderildi', 'gönderilecek', 'üretimde', 'iptal'.";
            const fullPrompt = `Mevcut sipariş verileri (JSON formatında): ${JSON.stringify(orders)}. Kullanıcı sorusu: "${promptText}"`;
            
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: fullPrompt,
                config: {
                    systemInstruction,
                }
            });
            setMessages(prev => [...prev.slice(0, -1), { role: 'ai', text: response.text }]);
        } catch (error) {
            console.error("Gemini API error:", error);
            setMessages(prev => [...prev.slice(0, -1), { role: 'ai', text: "Üzgünüm, bir hata oluştu. Lütfen tekrar deneyin." }]);
        } finally {
            setIsLoading(false);
        }
    };
    
    const summary = useMemo(() => {
        return {
            totalOrders: orders.length,
            totalValue: orders.reduce((sum, o) => sum + o.toplamPLN, 0),
            customers: new Set(orders.map(o => o.musteri)).size,
            products: new Set(orders.map(o => o.urun)).size,
        }
    }, [orders]);

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        handleSendMessage();
    };

    const suggestionChips = [
        "En yüksek değerli 3 siparişi listele",
        "Durumu 'üretimde' olan siparişler hangileri?",
        "En çok sipariş veren müşteri kim?",
        "Bu ay teslim edilecek siparişler",
    ];

    return (
        <div className="analiz-container">
            <div className="chat-panel">
                <div className="chat-header">
                     <h2 style={{display: 'flex', alignItems: 'center', gap: '12px'}}><MessageSquareIcon /> Analiz Asistanı</h2>
                </div>
                <div className="chat-messages">
                    {messages.map((msg, index) => (
                        <div key={index} className={`chat-message ${msg.role}`}>{msg.text}</div>
                    ))}
                </div>
                 {!isLoading && (
                    <div className="suggestion-chips">
                        {suggestionChips.map(chip => (
                            <div key={chip} className="chip" onClick={() => handleSendMessage(chip)}>{chip}</div>
                        ))}
                    </div>
                  )}
                <div className="chat-input-area">
                    <form className="chat-input-form" onSubmit={handleSubmit}>
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder="Siparişler hakkında bir soru sorun..."
                            disabled={isLoading}
                            aria-label="Analiz asistanına soru sor"
                        />
                        <button type="submit" className="btn btn-primary" disabled={isLoading || !input.trim()} aria-label="Gönder"><SendIcon /></button>
                    </form>
                </div>
            </div>
            <div className="analiz-sidebar">
                <div className="content-section">
                    <h2>Veri Özeti</h2>
                    <div className="analiz-summary-item"><span>Toplam Sipariş</span> <strong>{summary.totalOrders}</strong></div>
                    <div className="analiz-summary-item"><span>Toplam Değer</span> <strong>{summary.totalValue.toLocaleString('tr-TR')} PLN</strong></div>
                    <div className="analiz-summary-item"><span>Farklı Müşteri</span> <strong>{summary.customers}</strong></div>
                    <div className="analiz-summary-item"><span>Farklı Ürün</span> <strong>{summary.products}</strong></div>
                </div>
            </div>
        </div>
    );
};


export const SiparisModal: FC<{ closeModal: () => void; setOrders: React.Dispatch<React.SetStateAction<Order[]>>; allOrders: Order[]; orderToEdit: Order | null }> = ({ closeModal, setOrders, allOrders, orderToEdit }) => {
    const isEditMode = !!orderToEdit;
    const today = new Date().toISOString().split('T')[0];

    const initialOrderState: Omit<Order, 'id'> = {
        musteri: '', urun: '', tedarikci: '', seriNo: '', metre: 0, parca: 0, top: 0, toplamPLN: 0,
        durum: 'gönderilecek', siparisTarihi: today, teslimTarihi: '', aciklama: ''
    };

    const [orderData, setOrderData] = useState<Omit<Order, 'id'>>(
        isEditMode ? { ...orderToEdit } : initialOrderState
    );

    const uniqueCustomers = useMemo(() => [...new Set(allOrders.map(o => o.musteri))], [allOrders]);
    const uniqueSuppliers = useMemo(() => [...new Set(allOrders.map(o => o.tedarikci).filter(Boolean))], [allOrders]);

    const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { id, value } = e.target;
        const numValue = (e.target as HTMLInputElement).type === 'number' ? parseFloat(value) || 0 : value;
        setOrderData(prev => ({ ...prev, [id]: numValue }));
    }

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if (!orderData.musteri || !orderData.urun || !orderData.teslimTarihi) {
            alert("Lütfen Müşteri, Ürün ve Teslim Tarihi alanlarını doldurun.");
            return;
        }

        if (isEditMode) {
            setOrders(prev => prev.map(o => o.id === orderToEdit.id ? { ...orderData, id: o.id } : o));
        } else {
            const finalOrder: Order = {
                id: `S-${Date.now()}`,
                ...orderData,
            };
            setOrders(prev => [finalOrder, ...prev]);
        }
        closeModal();
    }

    return (
        <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="modal-header">
                        <h2>{isEditMode ? 'Siparişi Düzenle' : 'Yeni Sipariş Oluştur'}</h2>
                        <button type="button" onClick={closeModal} className="modal-close-btn" aria-label="Kapat"><XIcon /></button>
                    </div>
                    <div className="modal-body">
                        <div className="form-grid">
                            <div className="form-section-title">Temel Bilgiler</div>
                            <div className="form-group">
                                <label htmlFor="musteri">Müşteri</label>
                                <input list="customer-list" id="musteri" value={orderData.musteri} onChange={handleChange} required />
                                <datalist id="customer-list">
                                    {uniqueCustomers.map(c => <option key={c} value={c} />)}
                                </datalist>
                            </div>
                            <div className="form-group">
                                <label htmlFor="urun">Ürün</label>
                                <input type="text" id="urun" value={orderData.urun} onChange={handleChange} required />
                            </div>
                             <div className="form-group">
                                <label htmlFor="tedarikci">Tedarikçi</label>
                                <input list="supplier-list" id="tedarikci" value={orderData.tedarikci || ''} onChange={handleChange} />
                                <datalist id="supplier-list">
                                    {uniqueSuppliers.map(s => <option key={s} value={s} />)}
                                </datalist>
                            </div>
                            <div className="form-group">
                                <label htmlFor="seriNo">Seri No</label>
                                <input type="text" id="seriNo" value={orderData.seriNo} onChange={handleChange}/>
                            </div>
                             <div className="form-group">
                                <label htmlFor="siparisTarihi">Sipariş Tarihi</label>
                                <input type="date" id="siparisTarihi" value={orderData.siparisTarihi} onChange={handleChange} required />
                            </div>
                            <div className="form-group">
                                <label htmlFor="teslimTarihi">Teslim Tarihi</label>
                                <input type="date" id="teslimTarihi" value={orderData.teslimTarihi} onChange={handleChange} required min={isEditMode ? undefined : today} />
                            </div>

                            <div className="form-section-title">Miktar ve Değer</div>
                            <div className="form-group">
                                <label htmlFor="metre">Metre</label>
                                <input type="number" id="metre" value={orderData.metre} onChange={handleChange} />
                            </div>
                             <div className="form-group">
                                <label htmlFor="parca">Parça</label>
                                <input type="number" id="parca" value={orderData.parca} onChange={handleChange} />
                            </div>
                             <div className="form-group">
                                <label htmlFor="top">Top</label>
                                <input type="number" id="top" value={orderData.top} onChange={handleChange} />
                            </div>
                             <div className="form-group">
                                <label htmlFor="toplamPLN">Toplam PLN</label>
                                <input type="number" id="toplamPLN" value={orderData.toplamPLN} onChange={handleChange} />
                            </div>

                            <div className="form-section-title">Durum ve Notlar</div>
                             <div className="form-group">
                                <label htmlFor="durum">Durum</label>
                                <select id="durum" value={orderData.durum} onChange={handleChange}>
                                    {orderStatuses.map(s => <option key={s} value={s}>{statusTextMap[s]}</option>)}
                                </select>
                            </div>
                            <div className="form-group" style={{gridColumn: '1 / -1'}}>
                                <label htmlFor="aciklama">Açıklama</label>
                                <textarea id="aciklama" value={orderData.aciklama} onChange={handleChange}></textarea>
                            </div>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn" onClick={closeModal}>İptal</button>
                        <button type="submit" className="btn btn-primary">{isEditMode ? 'Değişiklikleri Kaydet' : 'Siparişi Kaydet'}</button>
                    </div>
                </form>
            </div>
        </div>
    )
}

// --- MAIN COMPONENT ---
const Siparisler = ({ action }: { action?: string | null }) => {
    type Tab = 'genelBakis' | 'tumSiparisler' | 'analiz';
    const [activeTab, setActiveTab] = useState<Tab>('tumSiparisler');
    const [isModalOpen, setModalOpen] = useState(false);
    const [orders, setOrders] = useState<Order[]>(initialOrders);
    const [editingOrder, setEditingOrder] = useState<Order | null>(null);

    const tabs: { id: Tab, label: string }[] = [
        { id: 'genelBakis', label: 'Genel Bakış' },
        { id: 'tumSiparisler', label: 'Tüm Siparişler' },
        { id: 'analiz', label: 'Analiz' }
    ];
    
    useEffect(() => {
        if (action === 'new_order') {
            handleEdit(null); // Open the modal for a new order
        }
    }, [action]);

    const handleEdit = (order: Order | null) => {
        setEditingOrder(order);
        setModalOpen(true);
    };

    const closeModal = () => {
        setModalOpen(false);
        setEditingOrder(null);
    };

    const renderTabContent = () => {
        switch (activeTab) {
            case 'genelBakis': return <GenelBakisTab orders={orders} />;
            case 'tumSiparisler': return <TumSiparislerTab orders={orders} setOrders={setOrders} handleEdit={handleEdit} />;
            case 'analiz': return <AnalizTab orders={orders} />;
            default: return null;
        }
    };

    return (
        <div className="page-container">
            <div className="page-header">
                <h1>Sipariş Yönetimi</h1>
            </div>
            <div className="tabs">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
                        onClick={() => setActiveTab(tab.id)}
                    >
                        {tab.label}
                    </button>
                ))}
            </div>
            <div className="tab-content">
                {renderTabContent()}
            </div>
            {isModalOpen && <SiparisModal closeModal={closeModal} setOrders={setOrders} allOrders={orders} orderToEdit={editingOrder} />}
        </div>
    );
};

export default Siparisler;