/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, FC, FormEvent, ChangeEvent, useEffect } from 'react';
import { Customer, CustomerStatus, Address, InvoiceType } from '../types';
import { initialCustomers } from '../data/mock';
import {
    CashIcon, CheckCircleIcon, CustomersIcon, DownloadIcon, EditIcon, FilterIcon,
    PlusIcon, SearchIcon, TrashIcon, UploadIcon, UserPlusIcon, XIcon
} from '../components/icons';

// --- MOCK DATA & TYPES ---
export const customerStatuses: CustomerStatus[] = ['Aktif', 'Pasif', 'Dondurulmuş'];
export const invoiceTypes: InvoiceType[] = ['Faturasız', 'Normal', 'Proforma'];
export const priorities = ['Düşük', 'Normal', 'Yüksek', 'Acil'];

// --- HELPER COMPONENTS ---
const EmptyState: FC<{ message: string }> = ({ message }) => (<div className="empty-state">{message}</div>);

const AnalizStatCard: FC<{
  icon: React.ReactNode;
  title: string;
  value: string | number;
}> = ({ icon, title, value }) => (
    <div className="musteriler-stat-card">
        <div className="icon-wrapper">{icon}</div>
        <div className="content-wrapper">
            <div className="title">{title}</div>
            <div className="value">{value}</div>
        </div>
    </div>
);


// --- TABS ---

const AnalizTab: FC<{ customers: Customer[] }> = ({ customers }) => {
    const stats = useMemo(() => {
        const total = customers.length;
        if (total === 0) return { total: 0, activeRatio: '0%', avgRevenue: '0,00', newLast30Days: 0 };

        const activeCustomers = customers.filter(c => c.durum === 'Aktif');
        const totalRevenue = customers.reduce((acc, c) => acc + c.toplamHarcama, 0);
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        const newLast30Days = customers.filter(c => new Date(c.kayitTarihi) > thirtyDaysAgo).length;

        return {
            total,
            activeRatio: `${total > 0 ? Math.round((activeCustomers.length / total) * 100) : 0}%`,
            avgRevenue: `${total > 0 ? (totalRevenue / total).toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0,00'}`,
            newLast30Days
        };
    }, [customers]);
    
    const topCustomers = useMemo(() => {
        return [...customers]
            .sort((a,b) => b.toplamHarcama - a.toplamHarcama)
            .slice(0, 5);
    }, [customers]);

    const maxHarcama = topCustomers.length > 0 ? topCustomers[0].toplamHarcama : 0;

    return (
        <div>
            <div className="musteriler-analiz-grid">
                <AnalizStatCard icon={<CustomersIcon/>} title="Toplam Müşteri" value={stats.total} />
                <AnalizStatCard icon={<CheckCircleIcon/>} title="Aktif Müşteri Oranı" value={stats.activeRatio} />
                <AnalizStatCard icon={<CashIcon/>} title="Müşteri Başına Ortalama Gelir" value={`${stats.avgRevenue} zł`} />
                <AnalizStatCard icon={<UserPlusIcon/>} title="Yeni Müşteri (Son 30 gün)" value={stats.newLast30Days} />
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px', marginTop: '24px' }}>
                <div className="content-section">
                    <h2>Ciroya Göre En İyi Müşteriler</h2>
                     {topCustomers.length > 0 ? (
                        <div className="analiz-chart-container">
                             <div className="bar-chart-horizontal">
                                {topCustomers.map(customer => (
                                    <div key={customer.id} className="bar-chart-item">
                                        <div className="bar-chart-label" title={customer.firmaAdi}>{customer.firmaAdi}</div>
                                        <div className="bar-chart-bar-bg">
                                            <div
                                                className="bar-chart-bar"
                                                style={{ width: `${maxHarcama > 0 ? (customer.toplamHarcama / maxHarcama) * 100 : 0}%` }}
                                            >
                                                {customer.toplamHarcama.toLocaleString('tr-TR')} zł
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    ) : (
                        <EmptyState message="Analiz için yeterli veri yok." />
                    )}
                </div>
                <div className="content-section">
                    <h2>Şehirlere Göre Müşteri Dağılımı</h2>
                    <EmptyState message="Analiz için yeterli veri yok." />
                </div>
            </div>
        </div>
    );
};

const MusteriListesiTab: FC<{
    customers: Customer[],
    setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>,
    handleEdit: (customer: Customer) => void,
    handleAddNew: () => void,
}> = ({ customers, setCustomers, handleEdit, handleAddNew }) => {
    const [searchTerm, setSearchTerm] = useState('');
    // Further filtering/pagination state can be added here

    const filteredCustomers = useMemo(() => {
        return customers.filter(c =>
            c.firmaAdi.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.irtibatKisisi.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
            c.vergiNumarasi.includes(searchTerm)
        );
    }, [customers, searchTerm]);
    
    const handleDelete = (id: string) => {
        if(window.confirm("Bu müşteriyi silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.")) {
            setCustomers(prev => prev.filter(p => p.id !== id));
        }
    };

    return (
        <div>
            <div className="toolbar">
                <div className="search-box">
                    <SearchIcon />
                    <input type="text" placeholder="İsim, firma, NIP, email ara..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
                </div>
                <div style={{ display: 'flex', gap: '12px' }}>
                    <button className="btn"><FilterIcon /> Filtrele</button>
                    <button className="btn"><UploadIcon /> İçeri Aktar</button>
                    <button className="btn"><DownloadIcon /> Dışa Aktar</button>
                    <button className="btn btn-primary" onClick={handleAddNew}><PlusIcon /> Yeni Müşteri Ekle</button>
                </div>
            </div>
            <div className="data-table-container">
                <table className="data-table">
                    <thead>
                        <tr><th>Müşteri</th><th>İletişim</th><th>Statü</th><th>Toplam Harcama</th><th>Son Sipariş</th><th>Senk. Durumu</th><th>Eylemler</th></tr>
                    </thead>
                    <tbody>
                        {filteredCustomers.length > 0 ? filteredCustomers.map(c => (
                            <tr key={c.id}>
                                <td><strong>{c.firmaAdi}</strong><br /><small>{c.kisaKod}</small></td>
                                <td>{c.irtibatKisisi}<br /><small>{c.email}</small></td>
                                <td>{c.durum}</td>
                                <td>{c.toplamHarcama.toLocaleString('tr-TR')} PLN</td>
                                <td>{c.sonSiparisTarihi ? new Date(c.sonSiparisTarihi).toLocaleDateString('tr-TR') : '-'}</td>
                                <td>{c.senkDurumu}</td>
                                <td className="table-actions">
                                    <button title="Düzenle" onClick={() => handleEdit(c)}><EditIcon /></button>
                                    <button title="Sil" onClick={() => handleDelete(c.id)}><TrashIcon /></button>
                                </td>
                            </tr>
                        )) : (
                            <tr><td colSpan={7}><EmptyState message="Arama kriterlerinize uygun sonuç bulunamadı." /></td></tr>
                        )}
                    </tbody>
                </table>
            </div>
            <div className="pagination">
                <span>{filteredCustomers.length} sonuçtan 1-{filteredCustomers.length} arası gösteriliyor</span>
                <div className="pagination-controls">
                    <button className="btn" disabled>Önceki</button>
                    <button className="btn" disabled>Sonraki</button>
                </div>
            </div>
        </div>
    );
};

// --- MODAL ---
export const MusteriModal: FC<{
    isOpen: boolean;
    closeModal: () => void;
    setCustomers: React.Dispatch<React.SetStateAction<Customer[]>>;
    customerToEdit: Customer | null;
}> = ({ isOpen, closeModal, setCustomers, customerToEdit }) => {
    const isEditMode = !!customerToEdit;
    const initialAddress: Address = { sokak: '', postaKodu: '', ilce: '', sehir: '', ulke: 'Polonya' };
    const initialFormState: Omit<Customer, 'id' | 'toplamHarcama' | 'sonSiparisTarihi' | 'senkDurumu'> = {
        firmaAdi: '', irtibatKisisi: '', musteriGrubu: '', kisaKod: '', kayitTarihi: '', kopya: false,
        vergiNumarasi: '', hesapNumarasi: '', vergiDairesi: '', faturaTipi: 'Faturasız',
        telefon1: '', telefon2: '', telefon3: '', email: '', internetSitesi: '', sosyalMedya: '',
        faturaAdresi: initialAddress,
        sevkiyatAdresi: initialAddress,
        sevkiyatAdresiAyni: true,
        durum: 'Aktif', oncelik: 'Normal', hatGuzergah: '', konumTuru: '', dosya: '', etiketler: '', aciklama: '',
    };

    const [customerData, setCustomerData] = useState(() => isEditMode ? customerToEdit : initialFormState);

    useEffect(() => {
        if (isOpen) {
            if(isEditMode) {
                 setCustomerData(customerToEdit);
            } else {
                setCustomerData({
                    ...initialFormState,
                    kayitTarihi: new Date().toISOString().split('T')[0],
                    kisaKod: `C-${Date.now().toString().slice(-4)}`
                });
            }
        }
    }, [isOpen, isEditMode, customerToEdit]);


    if (!isOpen) return null;
    
    const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        const checked = (e.target as HTMLInputElement).checked;
        
        if (name === 'sevkiyatAdresiAyni') {
            setCustomerData(prev => ({
                ...prev,
                sevkiyatAdresiAyni: checked,
                sevkiyatAdresi: checked ? prev.faturaAdresi : prev.sevkiyatAdresi
            }));
            return;
        }

        if (name.startsWith('faturaAdresi.')) {
            const field = name.split('.')[1];
            const newFaturaAdresi = {...customerData.faturaAdresi, [field]: value};
            setCustomerData(prev => ({ 
                ...prev, 
                faturaAdresi: newFaturaAdresi,
                sevkiyatAdresi: prev.sevkiyatAdresiAyni ? newFaturaAdresi : prev.sevkiyatAdresi
            }));
            return;
        }
        
        if (name.startsWith('sevkiyatAdresi.')) {
            const field = name.split('.')[1];
            setCustomerData(prev => ({ ...prev, sevkiyatAdresi: {...prev.sevkiyatAdresi, [field]: value}}));
            return;
        }

        setCustomerData(prev => ({...prev, [name]: type === 'checkbox' ? checked : value}));
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        if(!customerData.irtibatKisisi) {
            alert("Lütfen zorunlu alanları doldurun: İrtibat Kişisi");
            return;
        }

        if (isEditMode) {
            setCustomers(prev => prev.map(c => c.id === customerToEdit.id ? (customerData as Customer) : c));
        } else {
            const newCustomer: Customer = {
                ...customerData,
                id: `C-${Date.now()}`,
                toplamHarcama: 0,
                senkDurumu: 'Bekliyor',
            };
            setCustomers(prev => [newCustomer, ...prev]);
        }
        closeModal();
    };

    return (
        <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content" onClick={e => e.stopPropagation()}>
                <form onSubmit={handleSubmit}>
                    <div className="modal-header">
                        <h2>{isEditMode ? 'Müşteriyi Düzenle' : 'Yeni Müşteri Oluştur'}</h2>
                        <button type="button" onClick={closeModal} className="modal-close-btn" aria-label="Kapat"><XIcon /></button>
                    </div>
                    <div className="modal-body">
                        <div className="form-grid">
                            <h3 className="form-section-title">Kimlik Bilgileri</h3>
                            <div className="form-group"><label htmlFor="firmaAdi">Firma Adı</label><input type="text" name="firmaAdi" value={customerData.firmaAdi} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="irtibatKisisi">İrtibat Kişisi *</label><input type="text" name="irtibatKisisi" value={customerData.irtibatKisisi} onChange={handleChange} required /></div>
                            <div className="form-group"><label htmlFor="musteriGrubu">Müşteri Grubu</label><input type="text" name="musteriGrubu" value={customerData.musteriGrubu} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="kisaKod">Kısa Kod</label><input type="text" name="kisaKod" value={customerData.kisaKod} disabled placeholder="Otomatik"/></div>
                            <div className="form-group"><label htmlFor="kayitTarihi">Kayıt Tarihi</label><input type="text" name="kayitTarihi" value={customerData.kayitTarihi} disabled placeholder="Otomatik"/></div>
                            <div className="form-group" style={{alignItems: 'center', justifyContent: 'center'}}><label style={{display: 'flex', alignItems: 'center'}}><input type="checkbox" name="kopya" checked={customerData.kopya} onChange={handleChange} style={{width: 'auto', marginRight: '10px'}}/> Kopya (Çift Kayıt)</label></div>
                            
                            <h3 className="form-section-title">Finansal Bilgiler</h3>
                            <div className="form-group"><label htmlFor="vergiNumarasi">Vergi Numarası (NIP)</label><input type="text" name="vergiNumarasi" value={customerData.vergiNumarasi} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="hesapNumarasi">Hesap Numarası</label><input type="text" name="hesapNumarasi" value={customerData.hesapNumarasi} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="vergiDairesi">Vergi Dairesi</label><input type="text" name="vergiDairesi" value={customerData.vergiDairesi} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="faturaTipi">Fatura Tipi</label><select name="faturaTipi" value={customerData.faturaTipi} onChange={handleChange}>{invoiceTypes.map(t => <option key={t} value={t}>{t}</option>)}</select></div>

                            <h3 className="form-section-title">İletişim Bilgileri</h3>
                            <div className="form-group"><label htmlFor="telefon1">Telefon 1</label><input type="tel" name="telefon1" value={customerData.telefon1} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="telefon2">Telefon 2</label><input type="tel" name="telefon2" value={customerData.telefon2} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="telefon3">Telefon 3</label><input type="tel" name="telefon3" value={customerData.telefon3} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="email">E-posta</label><input type="email" name="email" value={customerData.email} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="internetSitesi">İnternet Sitesi</label><input type="url" name="internetSitesi" value={customerData.internetSitesi} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="sosyalMedya">Sosyal Medya</label><input type="text" name="sosyalMedya" value={customerData.sosyalMedya} onChange={handleChange} /></div>

                            <h3 className="form-section-title">Fatura Adresi</h3>
                            <div className="form-group" style={{gridColumn: '1 / -1'}}><label>Sokak ve Numara</label><input type="text" name="faturaAdresi.sokak" value={customerData.faturaAdresi.sokak} onChange={handleChange}/></div>
                            <div className="form-group"><label>Posta Kodu</label><input type="text" name="faturaAdresi.postaKodu" value={customerData.faturaAdresi.postaKodu} onChange={handleChange}/></div>
                            <div className="form-group"><label>İlçe</label><input type="text" name="faturaAdresi.ilce" value={customerData.faturaAdresi.ilce} onChange={handleChange}/></div>
                            <div className="form-group"><label>Şehir / İl</label><input type="text" name="faturaAdresi.sehir" value={customerData.faturaAdresi.sehir} onChange={handleChange}/></div>
                            <div className="form-group"><label>Ülke</label><input type="text" name="faturaAdresi.ulke" value={customerData.faturaAdresi.ulke} onChange={handleChange}/></div>
                            
                            <h3 className="form-section-title" style={{display: 'flex', justifyContent: 'space-between', alignItems: 'center'}}>
                                Sevkiyat Adresi
                                <label style={{display: 'flex', alignItems: 'center', fontSize: '0.9rem', fontWeight: '500'}}>
                                    <input type="checkbox" name="sevkiyatAdresiAyni" checked={customerData.sevkiyatAdresiAyni} onChange={handleChange} style={{width: 'auto', marginRight: '10px'}}/> 
                                    Sevkiyat adresi fatura adresiyle aynı
                                </label>
                            </h3>
                            <div className="form-group" style={{gridColumn: '1 / -1'}}><label>Sokak ve Numara</label><input type="text" name="sevkiyatAdresi.sokak" value={customerData.sevkiyatAdresi.sokak} onChange={handleChange} disabled={customerData.sevkiyatAdresiAyni}/></div>
                            <div className="form-group"><label>Posta Kodu</label><input type="text" name="sevkiyatAdresi.postaKodu" value={customerData.sevkiyatAdresi.postaKodu} onChange={handleChange} disabled={customerData.sevkiyatAdresiAyni}/></div>
                            <div className="form-group"><label>İlçe</label><input type="text" name="sevkiyatAdresi.ilce" value={customerData.sevkiyatAdresi.ilce} onChange={handleChange} disabled={customerData.sevkiyatAdresiAyni}/></div>
                            <div className="form-group"><label>Şehir / İl</label><input type="text" name="sevkiyatAdresi.sehir" value={customerData.sevkiyatAdresi.sehir} onChange={handleChange} disabled={customerData.sevkiyatAdresiAyni}/></div>
                            <div className="form-group"><label>Ülke</label><input type="text" name="sevkiyatAdresi.ulke" value={customerData.sevkiyatAdresi.ulke} onChange={handleChange} disabled={customerData.sevkiyatAdresiAyni}/></div>

                            <h3 className="form-section-title">Operasyonel Bilgiler</h3>
                            <div className="form-group"><label htmlFor="durum">Durum</label><select name="durum" value={customerData.durum} onChange={handleChange}>{customerStatuses.map(s => <option key={s} value={s}>{s}</option>)}</select></div>
                            <div className="form-group"><label htmlFor="oncelik">Öncelik</label><select name="oncelik" value={customerData.oncelik} onChange={handleChange}>{priorities.map(p => <option key={p} value={p}>{p}</option>)}</select></div>
                            <div className="form-group"><label htmlFor="hatGuzergah">Hat / Güzergâh</label><input type="text" name="hatGuzergah" value={customerData.hatGuzergah} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="konumTuru">Konum Türü</label><input type="text" name="konumTuru" value={customerData.konumTuru} onChange={handleChange} /></div>
                            <div className="form-group"><label htmlFor="dosya">Dosya</label><input type="text" name="dosya" value={customerData.dosya} onChange={handleChange} /></div>
                            <div className="form-group" style={{gridColumn: '1 / -1'}}><label htmlFor="etiketler">Etiketler (virgülle ayırın)</label><input type="text" name="etiketler" value={customerData.etiketler} onChange={handleChange} /></div>
                            <div className="form-group" style={{gridColumn: '1 / -1'}}><label htmlFor="aciklama">Açıklama</label><textarea name="aciklama" value={customerData.aciklama} onChange={handleChange} /></div>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn" onClick={closeModal}>İptal</button>
                        <button type="submit" className="btn btn-primary">{isEditMode ? 'Değişiklikleri Kaydet' : 'Müşteriyi Kaydet'}</button>
                    </div>
                </form>
            </div>
        </div>
    );
}

// --- MAIN COMPONENT ---
const Musteriler = ({ action }: { action?: string | null }) => {
    type Tab = 'analiz' | 'musteriListesi';
    const [activeTab, setActiveTab] = useState<Tab>('analiz');
    const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
    const [isModalOpen, setModalOpen] = useState(false);
    const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

    const tabs: { id: Tab, label: string }[] = [
        { id: 'analiz', label: 'Analiz' },
        { id: 'musteriListesi', label: 'Müşteri Listesi' },
    ];

    useEffect(() => {
        if (action === 'new_customer') {
            handleAddNew();
        }
    }, [action]);
    
    const handleEdit = (customer: Customer) => {
        setEditingCustomer(customer);
        setModalOpen(true);
    };

    const handleAddNew = () => {
        setEditingCustomer(null);
        setModalOpen(true);
    }

    const closeModal = () => {
        setModalOpen(false);
        setEditingCustomer(null);
    };

    const renderTabContent = () => {
        switch (activeTab) {
            case 'analiz': return <AnalizTab customers={customers} />;
            case 'musteriListesi': return <MusteriListesiTab customers={customers} setCustomers={setCustomers} handleEdit={handleEdit} handleAddNew={handleAddNew} />;
            default: return null;
        }
    };

    return (
        <div className="page-container">
            <div className="page-header">
                <h1>Müşteriler</h1>
            </div>
            <div className="tabs">
                {tabs.map(tab => (
                    <button
                        key={tab.id}
                        className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
                        onClick={() => setActiveTab(tab.id)}
                    >{tab.label}</button>
                ))}
            </div>
            <div className="tab-content">
                {renderTabContent()}
            </div>
            {isModalOpen && <MusteriModal isOpen={isModalOpen} closeModal={closeModal} setCustomers={setCustomers} customerToEdit={editingCustomer} />}
        </div>
    );
};

export default Musteriler;