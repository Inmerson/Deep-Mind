/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Page, PageComponentProps } from '../types';

import Almanya from './Almanya';
import Anasayfa from './Anasayfa';
import Ayarlar from './Ayarlar';
import CopKutusu from './CopKutusu';
import Gecmis from './Gecmis';
import Kasa from './Kasa';
import Kargo from './Kargo';
import Liste from './Liste';
import Mail from './Mail';
import Musteriler from './Musteriler';
import Siparisler from './Siparisler';
import StokYonetimi from './StokYonetimi';
import TurRehberi from './TurRehberi';

// A map of page components for easy rendering
export const pageComponents: Record<Page, React.ComponentType<PageComponentProps>> = {
  anasayfa: Anasayfa,
  liste: Liste,
  siparisler: Siparisler,
  kargo: Kargo,
  stokYonetimi: StokYonetimi,
  musteriler: Musteriler,
  almanya: Almanya,
  turRehberi: TurRehberi,
  kasa: Kasa,
  mail: Mail,
  copKutusu: CopKutusu,
  gecmis: Gecmis,
  ayarlar: Ayarlar,
};