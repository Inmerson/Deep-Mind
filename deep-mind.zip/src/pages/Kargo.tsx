/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { TruckIcon } from '../components/icons';

const EmptyState: React.FC<{
  title: string;
  message: string;
  icon: React.ReactNode;
}> = ({ title, message, icon }) => (
  <div
    className="empty-state"
    style={{
      paddingTop: '100px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '24px',
    }}
  >
    <div style={{ color: 'var(--secondary-text-color)' }}>{icon}</div>
    <div style={{display: 'flex', flexDirection: 'column', gap: '8px'}}>
        <h2 style={{margin: 0, fontSize: '1.5rem'}}>{title}</h2>
        <p style={{margin: 0, maxWidth: '400px'}}>{message}</p>
    </div>
  </div>
);

const Kargo = () => {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Kargo</h1>
      </div>
      <EmptyState
        title="Bu Sayfa Geliştirme Aşamasında"
        message="Kargo ve sevkiyat yönetimi özellikleri yakında burada olacak. Anlayışınız için teşekkür ederiz."
        icon={<TruckIcon style={{ width: '64px', height: '64px' }} />}
      />
    </div>
  );
};

export default Kargo;