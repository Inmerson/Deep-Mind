/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, FC, FormEvent, useEffect } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { PlusIcon, CalendarIcon, ListOrderedIcon, ArchiveIcon } from '../components/icons';

type TodoItem = {
  id: number;
  text: string;
  completed: boolean;
};

type ListType = 'Günlük' | 'Haftalık' | 'Aylık';
type ActiveTab = 'todos' | 'goals';

const TodoColumn: FC<{ title: ListType; icon: React.ReactNode }> = ({ title, icon }) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('todos');
  const [todos, setTodos] = useState<TodoItem[]>([]);
  const [goals, setGoals] = useState<TodoItem[]>([]);
  const [newItemText, setNewItemText] = useState('');
  const [isLoadingAI, setIsLoadingAI] = useState(false);

  const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY as string }), []);

  // Example initial data to match the screenshot
  useEffect(() => {
    if (title === 'Günlük') {
      setTodos([{ id: 1, text: 'furkani ara', completed: true }]);
    }
  }, [title]);

  const items = activeTab === 'todos' ? todos : goals;
  const setItems = activeTab === 'todos' ? setTodos : setGoals;

  const handleAddItem = (e: FormEvent) => {
    e.preventDefault();
    if (newItemText.trim() === '') return;
    const newItem: TodoItem = {
      id: Date.now(),
      text: newItemText.trim(),
      completed: false,
    };
    setItems(prevItems => [...prevItems, newItem]);
    setNewItemText('');
  };

  const handleToggleItem = (id: number) => {
    setItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, completed: !item.completed } : item
      )
    );
  };

  const handleClearCompleted = () => {
    setItems(prevItems => prevItems.filter(item => !item.completed));
  };
  
  const handleGetAISuggestions = async () => {
    setIsLoadingAI(true);
    const promptText = `Bana Türkiye'deki birisi için ${title.toLowerCase()} ${activeTab === 'todos' ? 'yapılacaklar listesi' : 'hedefler'} için 3 kısa ve genel öneride bulun. Öneriler Türkçe olmalı.`;
    
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: promptText,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              suggestions: {
                type: Type.ARRAY,
                items: {
                  type: Type.STRING,
                  description: 'A single suggestion'
                }
              }
            }
          }
        }
      });
      
      const jsonResponse = JSON.parse(response.text);
      if (jsonResponse.suggestions && Array.isArray(jsonResponse.suggestions)) {
        const newItems: TodoItem[] = jsonResponse.suggestions.map((text: string) => ({
          id: Date.now() + Math.random(),
          text,
          completed: false,
        }));
        setItems(prev => [...prev, ...newItems]);
      }
    } catch (error) {
      console.error("AI suggestion error:", error);
      alert("AI önerileri alınırken bir hata oluştu. Lütfen tekrar deneyin.");
    } finally {
      setIsLoadingAI(false);
    }
  };

  const todosCount = todos.length;
  const goalsCount = goals.length;
  const currentList = activeTab === 'todos' ? todos : goals;

  return (
    <div className="todo-column" aria-labelledby={`${title}-heading`}>
      <div className="todo-column-header">
        <div className="title-group">
          {icon}
          <h3 id={`${title}-heading`}>{title}</h3>
        </div>
        <button className="ai-suggestion-btn" onClick={handleGetAISuggestions} disabled={isLoadingAI}>
          {isLoadingAI ? '...' : 'AI Öneri'}
        </button>
      </div>
      <div className="tabs-container" role="tablist">
        <button 
          id={`tab-${title}-todos`}
          className={`tab-btn ${activeTab === 'todos' ? 'active' : ''}`}
          onClick={() => setActiveTab('todos')}
          role="tab"
          aria-selected={activeTab === 'todos'}
          aria-controls={`panel-${title}-todos`}
        >
          Yapılacaklar ({todosCount})
        </button>
        <button
          id={`tab-${title}-goals`}
          className={`tab-btn ${activeTab === 'goals' ? 'active' : ''}`}
          onClick={() => setActiveTab('goals')}
          role="tab"
          aria-selected={activeTab === 'goals'}
          aria-controls={`panel-${title}-goals`}
        >
          Hedefler ({goalsCount})
        </button>
      </div>
      <div 
        id={`panel-${title}-${activeTab}`}
        className="item-list"
        role="tabpanel"
        aria-labelledby={`tab-${title}-${activeTab}`}
      >
        {currentList.length > 0 ? (
          currentList.map(item => (
            <div key={item.id} className="todo-item">
              <input 
                type="checkbox" 
                id={`item-${item.id}`} 
                checked={item.completed}
                onChange={() => handleToggleItem(item.id)}
              />
              <label htmlFor={`item-${item.id}`} className={item.completed ? 'completed' : ''}>
                {item.text}
              </label>
            </div>
          ))
        ) : (
          <p className="empty-list-message">Liste boş</p>
        )}
      </div>
      <form className="add-item-form" onSubmit={handleAddItem}>
        <input 
          type="text" 
          placeholder="Yeni öğe ekle..." 
          value={newItemText}
          onChange={e => setNewItemText(e.target.value)}
          aria-label={`Yeni ${title} ${activeTab === 'todos' ? 'yapılacak' : 'hedef'} ekle`}
        />
        <button type="submit" aria-label="Yeni öğe ekle">
          <PlusIcon />
        </button>
      </form>
      <div className="todo-column-footer">
        <button className="clear-completed-btn" onClick={handleClearCompleted}>
          Tamamlananları Temizle
        </button>
      </div>
    </div>
  );
};


const Liste = ({ action }: { action?: string | null }) => {
  return (
    <div className="page-container">
       <div className="page-header">
        <h1>Görev Listeleri</h1>
      </div>
      <div className="liste-page-container" style={{ padding: 0, flex: 1 }}>
        <TodoColumn title="Günlük" icon={<CalendarIcon aria-label="Günlük liste ikonu"/>} />
        <TodoColumn title="Haftalık" icon={<ListOrderedIcon aria-label="Haftalık liste ikonu" />} />
        <TodoColumn title="Aylık" icon={<ArchiveIcon aria-label="Aylık liste ikonu" />} />
      </div>
    </div>
  );
};

export default Liste;