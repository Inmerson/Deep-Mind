/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { SettingsIcon } from '../components/icons';

const EmptyState: React.FC<{
  title: string;
  message: string;
  icon: React.ReactNode;
}> = ({ title, message, icon }) => (
  <div
    className="empty-state"
    style={{
      paddingTop: '100px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: '24px',
    }}
  >
    <div style={{ color: 'var(--secondary-text-color)' }}>{icon}</div>
    <div style={{display: 'flex', flexDirection: 'column', gap: '8px'}}>
        <h2 style={{margin: 0, fontSize: '1.5rem'}}>{title}</h2>
        <p style={{margin: 0, maxWidth: '400px'}}>{message}</p>
    </div>
  </div>
);

const Gecmis = () => {
  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Geçmiş</h1>
      </div>
       <EmptyState
        title="Bu Sayfa Geliştirme Aşamasında"
        message="Bu özellik yakında kullanımınıza sunulacaktır. Anlayışınız için teşekkür ederiz."
        icon={<SettingsIcon style={{ width: '64px', height: '64px' }} />}
      />
    </div>
  );
};

export default Gecmis;