/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import React, { useContext, useState, useMemo, FC, FormEvent, ChangeEvent } from 'react';
import { NavigationContext } from '../App';
import {
  HistoryIcon,
  BarChartIcon,
  LightningIcon,
  ListOrderedIcon,
  PlusIcon,
  PackageIcon,
  SwapHorizontalIcon,
  UserPlusIcon,
  XIcon,
} from '../components/icons';
import { Page, Order, Product, Customer, StockMovement, StockMovementType, ProductType, ProductUnit, CustomerStatus, InvoiceType } from '../types';
import { initialOrders, initialProducts, initialCustomers, initialMovements } from '../data/mock';

import { SiparisModal, orderStatuses, statusTextMap } from './Siparisler';
import { UrunModal, productTypes, productUnits } from './StokYonetimi';
import { MusteriModal, customerStatuses, invoiceTypes, priorities } from './Musteriler';

// --- Stock Movement Modal (New) ---
const StockMovementModal: FC<{
  closeModal: () => void;
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  setMovements: React.Dispatch<React.SetStateAction<StockMovement[]>>;
}> = ({ closeModal, products, setProducts, setMovements }) => {
    const [movementData, setMovementData] = useState({
        productId: '',
        type: 'Giriş' as StockMovementType,
        quantity: 1,
        description: '',
    });

    const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
        const { name, value, type } = e.target;
        setMovementData(prev => ({
            ...prev,
            [name]: type === 'number' ? parseFloat(value) || 0 : value,
        }));
    };

    const handleSubmit = (e: FormEvent) => {
        e.preventDefault();
        const { productId, type, quantity, description } = movementData;
        const product = products.find(p => p.id === productId);

        if (!product || quantity <= 0) {
            alert('Lütfen geçerli bir ürün seçin ve miktarı 0\'dan büyük girin.');
            return;
        }

        const newMovement: StockMovement = {
            id: `SM-${Date.now()}`,
            date: new Date().toISOString(),
            productId: product.id,
            productName: product.name,
            type: type,
            quantity: type === 'Giriş' ? quantity : -quantity,
            description,
            user: 'Admin'
        };
        
        setMovements(prev => [newMovement, ...prev]);

        setProducts(prev => prev.map(p => 
            p.id === productId 
            ? { ...p, currentStock: p.currentStock + newMovement.quantity } 
            : p
        ));

        closeModal();
    };

    return (
        <div className="modal-overlay" onClick={closeModal}>
            <div className="modal-content" onClick={e => e.stopPropagation()} style={{maxWidth: '600px'}}>
                <form onSubmit={handleSubmit}>
                    <div className="modal-header">
                        <h2>Stok Hareketi Ekle</h2>
                        <button type="button" onClick={closeModal} className="modal-close-btn" aria-label="Kapat"><XIcon /></button>
                    </div>
                    <div className="modal-body">
                        <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
                            <div className="form-group">
                                <label htmlFor="productId">Ürün</label>
                                <select name="productId" value={movementData.productId} onChange={handleChange} required>
                                    <option value="" disabled>Ürün Seçin...</option>
                                    {products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.sku})</option>)}
                                </select>
                            </div>
                            <div style={{display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px'}}>
                                <div className="form-group">
                                    <label htmlFor="type">İşlem Tipi</label>
                                    <select name="type" value={movementData.type} onChange={handleChange} required>
                                        <option value="Giriş">Giriş</option>
                                        <option value="Çıkış">Çıkış</option>
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label htmlFor="quantity">Miktar</label>
                                    <input type="number" name="quantity" value={movementData.quantity} onChange={handleChange} required min="1" />
                                </div>
                            </div>
                            <div className="form-group">
                                <label htmlFor="description">Açıklama</label>
                                <textarea name="description" value={movementData.description} onChange={handleChange} />
                            </div>
                        </div>
                    </div>
                    <div className="modal-footer">
                        <button type="button" className="btn" onClick={closeModal}>İptal</button>
                        <button type="submit" className="btn btn-primary">Hareketi Kaydet</button>
                    </div>
                </form>
            </div>
        </div>
    )
}


const DashboardCard = ({ icon, title, children, className = '' }: { icon: React.ReactNode; title: string; children: React.ReactNode; className?: string }) => (
  <div className={`dashboard-card ${className}`}>
    <div className="card-header">
      <div className="card-header-icon">{icon}</div>
      <h2 className="card-header-title">{title}</h2>
    </div>
    {children}
  </div>
);

const QuickLookCard = () => (
  <DashboardCard icon={<HistoryIcon />} title="Hızlı Bakış" className="quick-look-card">
    <div className="quick-look-stats">
      <div className="stat-item">
        <span className="stat-item-label">Son 30 Gün Ciro</span>
        <span className="stat-item-value">0,00 zł</span>
      </div>
      <div className="stat-item">
        <span className="stat-item-label">Toplam Müşteri</span>
        <span className="stat-item-value">3</span>
      </div>
      <div className="stat-item">
        <span className="stat-item-label">Kritik seviyedeki ürünler</span>
        <span className="stat-item-value">1</span>
      </div>
      <div className="stat-item">
        <span className="stat-item-label">Toplam Stok Değeri</span>
        <span className="stat-item-value small">Hesaplanamadı</span>
      </div>
    </div>
  </DashboardCard>
);

const QuickAccessCard = ({ onActionClick }: { onActionClick: (action: string) => void }) => {
  const accessItems: {
    icon: JSX.Element;
    title: string;
    desc: string;
    color: string;
    action: string;
  }[] = [
    {
      icon: <PlusIcon />,
      title: "Yeni Sipariş Oluştur",
      desc: "Hızlıca yeni bir satış kaydı açın.",
      color: '#e88338',
      action: 'new_order'
    },
    {
      icon: <PackageIcon />,
      title: "Yeni Ürün Tanımla",
      desc: "Stok listenize yeni bir kalem ekleyin.",
      color: '#4285f4',
      action: 'new_product'
    },
    {
      icon: <SwapHorizontalIcon />,
      title: "Stok Hareketi Ekle",
      desc: "Manuel stok girişi veya çıkışı yapın.",
      color: '#80868b',
      action: 'new_stock_movement'
    },
    {
      icon: <UserPlusIcon />,
      title: "Yeni Müşteri Ekle",
      desc: "Yeni bir müşteri profili oluşturun.",
      color: '#3ddc84',
      action: 'new_customer'
    },
  ];

  return (
    <DashboardCard icon={<LightningIcon style={{ color: '#3ddc84' }} />} title="Hızlı Erişim" className="quick-access-card">
      <ul className="quick-access-list">
        {accessItems.map((item, index) => (
          <li key={index} className="quick-access-item" tabIndex={0} role="button" onClick={() => onActionClick(item.action)}>
            <div className="quick-access-icon" style={{ backgroundColor: item.color, color: 'white' }}>
              {item.icon}
            </div>
            <div className="quick-access-info">
              <span className="quick-access-title">{item.title}</span>
              <span className="quick-access-desc">{item.desc}</span>
            </div>
          </li>
        ))}
      </ul>
    </DashboardCard>
  );
};

const WeeklyActivityCard = () => {
    const days = ["Cmt", "Paz", "Pzt", "Sal", "Çar", "Per", "Cum"];
    const data = [10, 5, 30, 80, 50, 60, 95]; // Example data
    const maxVal = Math.max(...data);
    
    return (
        <DashboardCard icon={<BarChartIcon />} title="Haftalık Sipariş Aktivitesi" className="weekly-activity-card">
            <div className="chart-container">
                <div className="bar-chart-placeholder">
                    {data.map((value, index) => (
                      <div 
                        key={index} 
                        className="bar" 
                        style={{ height: `${(value / maxVal) * 100}%` }}
                        title={`${value} sipariş`}
                      ></div>
                    ))}
                </div>
                <div className="chart-labels">
                    {days.map(day => <div key={day}>{day}</div>)}
                </div>
            </div>
        </DashboardCard>
    );
};

const RecentOrdersCard = () => (
    <DashboardCard icon={<ListOrderedIcon />} title="Son Siparişler" className="recent-orders-card">
        <div className="recent-orders-content">
            <p>Henüz sipariş yok.</p>
        </div>
    </DashboardCard>
);


const Anasayfa = ({ action }: { action?: string | null }) => {
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [customers, setCustomers] = useState<Customer[]>(initialCustomers);
  const [movements, setMovements] = useState<StockMovement[]>(initialMovements);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const closeModal = () => setActiveModal(null);

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Gösterge Paneli</h1>
      </div>
      <div className="dashboard-grid" style={{flex: 1}}>
        <QuickLookCard />
        <QuickAccessCard onActionClick={setActiveModal} />
        <WeeklyActivityCard />
        <RecentOrdersCard />
      </div>

      {activeModal === 'new_order' && <SiparisModal closeModal={closeModal} setOrders={setOrders} allOrders={orders} orderToEdit={null} />}
      {activeModal === 'new_product' && <UrunModal isOpen={true} closeModal={closeModal} setProducts={setProducts} productToEdit={null} />}
      {activeModal === 'new_customer' && <MusteriModal isOpen={true} closeModal={closeModal} setCustomers={setCustomers} customerToEdit={null} />}
      {activeModal === 'new_stock_movement' && <StockMovementModal closeModal={closeModal} products={products} setProducts={setProducts} setMovements={setMovements} />}
    </div>
  );
};

export default Anasayfa;