/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, FC, FormEvent, ChangeEvent, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Product, ProductType, ProductUnit, StockMovement, StockMovementType } from '../types';
import { initialProducts, initialMovements } from '../data/mock';
import {
  AlertTriangleIcon, BanIcon, EditIcon, FilterIcon, GridIcon, LightbulbIcon,
  PlusIcon, SearchIcon, SparklesIcon, TrashIcon, UploadIcon, XIcon, DownloadIcon
} from '../components/icons';

// --- MOCK DATA ---
export const productTypes: ProductType[] = ['Parça', 'Top', 'Kartela', 'Diğer'];
export const productUnits: ProductUnit[] = ['Adet', 'Metre', 'KG', 'Paket'];

// --- HELPER COMPONENTS ---
const EmptyState: FC<{ message: string }> = ({ message }) => (
  <div className="empty-state">{message}</div>
);

// --- MODAL ---
export const UrunModal: FC<{
  isOpen: boolean;
  closeModal: () => void;
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  productToEdit: Product | null;
}> = ({ isOpen, closeModal, setProducts, productToEdit }) => {
  const isEditMode = !!productToEdit;
  const initialFormState: Omit<Product, 'id'> = {
    name: '', sku: '', type: 'Parça', supplier: '',
    currentStock: 0, criticalStock: 0, unit: 'Adet',
    lastEntryDate: new Date().toISOString().split('T')[0], notes: ''
  };

  const [productData, setProductData] = useState(isEditMode ? { ...productToEdit } : initialFormState);
  const [isGeneratingNote, setIsGeneratingNote] = useState(false);
  const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY as string }), []);

  useEffect(() => {
    setProductData(isEditMode ? { ...productToEdit } : initialFormState);
  }, [isOpen, productToEdit]);

  if (!isOpen) return null;

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value, type } = e.target;
    setProductData(prev => ({
      ...prev,
      [name]: type === 'number' ? parseFloat(value) || 0 : value,
    }));
  };
  
  const handleGenerateNote = async () => {
      if (!productData.name) {
          alert("Lütfen bir ürün adı girin.");
          return;
      }
      setIsGeneratingNote(true);
      try {
          const prompt = `Bana şu ürün için kısa, pazarlama odaklı bir not/açıklama metni oluştur: Ürün Adı: '${productData.name}', Ürün Tipi: '${productData.type}'. Açıklama Türkçe ve 2-3 cümle olsun.`;
          const response = await ai.models.generateContent({
              model: 'gemini-2.5-flash',
              contents: prompt,
          });
          setProductData(prev => ({ ...prev, notes: response.text }));
      } catch (error) {
          console.error("AI note generation error:", error);
          alert("AI not oluştururken bir hata oluştu.");
      } finally {
          setIsGeneratingNote(false);
      }
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!productData.name || !productData.type || !productData.unit) {
      alert("Lütfen yıldızlı alanları doldurun.");
      return;
    }

    if (isEditMode) {
      setProducts(prev => prev.map(p => p.id === productToEdit.id ? { ...productData, id: p.id } : p));
    } else {
      const newProduct: Product = { ...productData, id: `P-${Date.now()}` };
      setProducts(prev => [newProduct, ...prev]);
    }
    closeModal();
  };

  return (
    <div className="modal-overlay" onClick={closeModal}>
      <div className="modal-content" onClick={e => e.stopPropagation()}>
        <form onSubmit={handleSubmit}>
          <div className="modal-header">
            <h2>{isEditMode ? 'Ürünü Düzenle' : 'Yeni Ürün Ekle'}</h2>
            <button type="button" onClick={closeModal} className="modal-close-btn" aria-label="Kapat"><XIcon /></button>
          </div>
          <div className="modal-body">
            <div className="form-grid">
              <h3 className="form-section-title">Ürün Bilgileri</h3>
              <div className="form-group"><label htmlFor="name">Ürün Adı *</label><input type="text" name="name" value={productData.name} onChange={handleChange} required /></div>
              <div className="form-group"><label htmlFor="sku">Ürün Kodu (SKU)</label><input type="text" name="sku" value={productData.sku} onChange={handleChange} /></div>
              <div className="form-group"><label htmlFor="type">Ürün Tipi *</label><select name="type" value={productData.type} onChange={handleChange}>{productTypes.map(t => <option key={t} value={t}>{t}</option>)}</select></div>
              <div className="form-group"><label htmlFor="supplier">Tedarikçi</label><input type="text" name="supplier" value={productData.supplier} onChange={handleChange} /></div>

              <h3 className="form-section-title">Stok Bilgileri</h3>
              <div className="form-group"><label htmlFor="currentStock">Mevcut Stok *</label><input type="number" name="currentStock" value={productData.currentStock} onChange={handleChange} required /></div>
              <div className="form-group"><label htmlFor="criticalStock">Kritik Stok Seviyesi *</label><input type="number" name="criticalStock" value={productData.criticalStock} onChange={handleChange} required /></div>
              <div className="form-group"><label htmlFor="unit">Birim *</label><select name="unit" value={productData.unit} onChange={handleChange}>{productUnits.map(u => <option key={u} value={u}>{u}</option>)}</select></div>
              <div className="form-group note-group" style={{ gridColumn: '1 / -1' }}>
                <label htmlFor="notes">Notlar</label>
                <textarea name="notes" value={productData.notes} onChange={handleChange}></textarea>
                <button type="button" className="btn btn-primary note-ai-btn" onClick={handleGenerateNote} disabled={isGeneratingNote}>
                    <SparklesIcon width="16" height="16" /> {isGeneratingNote ? '...' : 'AI ile Oluştur'}
                </button>
              </div>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn" onClick={closeModal}>İptal</button>
            <button type="submit" className="btn btn-primary">{isEditMode ? 'Kaydet' : 'Ürünü Ekle'}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

// --- TABS ---

const GenelBakisTab: FC<{ products: Product[] }> = ({ products }) => {
  const stats = useMemo(() => ({
    totalVariety: products.length,
    criticalLevel: products.filter(p => p.currentStock > 0 && p.currentStock <= p.criticalStock).length,
    outOfStock: products.filter(p => p.currentStock === 0).length,
  }), [products]);

  return (
    <div className="stok-overview-container">
      <div className="overview-stat-card">
        <div className="icon-container"><GridIcon /></div>
        <div className="info">
          <span className="title">Toplam Ürün Çeşidi</span>
          <span className="value">{stats.totalVariety}</span>
        </div>
      </div>
      <div className="overview-stat-card">
        <div className="icon-container" style={{color: 'var(--warning-color)'}}><AlertTriangleIcon /></div>
        <div className="info">
          <span className="title">Kritik Seviyede</span>
          <span className="value">{stats.criticalLevel}</span>
        </div>
      </div>
      <div className="overview-stat-card">
        <div className="icon-container" style={{color: 'var(--danger-color)'}}><BanIcon /></div>
        <div className="info">
          <span className="title">Stokta Olmayan</span>
          <span className="value">{stats.outOfStock}</span>
        </div>
      </div>
      <div className="analysis-section">
        <div className="analysis-card">
          <h3>En Çok Stoğa Sahip Ürünler (TOP 10)</h3>
          <div className="content"><EmptyState message="Analiz için yeterli veri yok." /></div>
        </div>
        <div className="analysis-card">
          <h3>Ürün Tipine Göre Dağılım</h3>
          <div className="content"><EmptyState message="Analiz için yeterli veri yok." /></div>
        </div>
      </div>
    </div>
  );
};

const UrunlerTab: FC<{
  products: Product[],
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>,
  handleEdit: (product: Product) => void,
  handleAddNew: () => void,
}> = ({ products, setProducts, handleEdit, handleAddNew }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTypeFilter, setActiveTypeFilter] = useState<ProductType | 'Tümü'>('Tümü');
  const [sortConfig, setSortConfig] = useState<{ key: keyof Product; direction: 'asc' | 'desc' } | null>({ key: 'name', direction: 'asc'});

  const sortedAndFilteredProducts = useMemo(() => {
    let sortableItems = [...products]
      .filter(p => activeTypeFilter === 'Tümü' || p.type === activeTypeFilter)
      .filter(p =>
        p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        p.sku.toLowerCase().includes(searchTerm.toLowerCase())
      );

    if (sortConfig !== null) {
      sortableItems.sort((a, b) => {
        if (a[sortConfig.key] < b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? -1 : 1;
        }
        if (a[sortConfig.key] > b[sortConfig.key]) {
          return sortConfig.direction === 'asc' ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [products, searchTerm, activeTypeFilter, sortConfig]);
  
  const requestSort = (key: keyof Product) => {
    let direction: 'asc' | 'desc' = 'asc';
    if (sortConfig && sortConfig.key === key && sortConfig.direction === 'asc') {
      direction = 'desc';
    }
    setSortConfig({ key, direction });
  };

  const getSortIndicator = (key: keyof Product) => {
    if (!sortConfig || sortConfig.key !== key) return null;
    return <span style={{color: '#4285F4', paddingLeft: '4px', display: 'inline-block'}}>{sortConfig.direction === 'desc' ? '▼' : '▲'}</span>;
  }
  
  const handleDelete = (id: string) => {
      if(window.confirm("Bu ürünü silmek istediğinizden emin misiniz? Bu işlem geri alınamaz.")) {
          setProducts(prev => prev.filter(p => p.id !== id));
      }
  };

  return (
    <div>
      <div className="tabs">
        {(['Tümü', ...productTypes] as const).map(type => (
          <button
            key={type}
            className={`tab-btn ${activeTypeFilter === type ? 'active' : ''}`}
            onClick={() => setActiveTypeFilter(type)}
          >{type}</button>
        ))}
      </div>
      <div className="toolbar" style={{ marginTop: '24px' }}>
        <div className="search-box">
          <SearchIcon />
          <input type="text" placeholder="Ürün adı veya kodu ara..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
        </div>
        <div style={{ display: 'flex', gap: '12px' }}>
          <button className="btn"><FilterIcon /> Filtrele</button>
          <button className="btn"><UploadIcon /> İçeri Aktar</button>
          <button className="btn"><DownloadIcon /> Dışa Aktar</button>
          <button className="btn btn-primary" onClick={handleAddNew}><PlusIcon /> Yeni Ürün Ekle</button>
        </div>
      </div>
      <div className="data-table-container">
        <table className="data-table">
          <thead>
            <tr>
              <th className="sortable" onClick={() => requestSort('name')}>Ürün Adı {getSortIndicator('name')}</th>
              <th className="sortable" onClick={() => requestSort('sku')}>SKU {getSortIndicator('sku')}</th>
              <th className="sortable" onClick={() => requestSort('type')}>Ürün Tipi {getSortIndicator('type')}</th>
              <th className="sortable" onClick={() => requestSort('supplier')}>Tedarikçi {getSortIndicator('supplier')}</th>
              <th className="sortable" onClick={() => requestSort('currentStock')}>Mevcut Stok {getSortIndicator('currentStock')}</th>
              <th className="sortable" onClick={() => requestSort('criticalStock')}>Kritik Stok {getSortIndicator('criticalStock')}</th>
              <th>Birim</th>
              <th className="sortable" onClick={() => requestSort('lastEntryDate')}>Son Giriş Tarihi {getSortIndicator('lastEntryDate')}</th>
              <th>Eylemler</th>
            </tr>
          </thead>
          <tbody>
            {sortedAndFilteredProducts.length > 0 ? sortedAndFilteredProducts.map(p => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.sku}</td>
                <td>{p.type}</td>
                <td>{p.supplier}</td>
                <td>{p.currentStock}</td>
                <td>{p.criticalStock}</td>
                <td>{p.unit}</td>
                <td>{new Date(p.lastEntryDate).toLocaleDateString('tr-TR')}</td>
                <td className="table-actions">
                  <button title="Düzenle" onClick={() => handleEdit(p)}><EditIcon /></button>
                  <button title="Sil" onClick={() => handleDelete(p.id)}><TrashIcon /></button>
                </td>
              </tr>
            )) : (
              <tr><td colSpan={9}><EmptyState message="Arama kriterlerinize uygun stok bulunamadı." /></td></tr>
            )}
          </tbody>
        </table>
      </div>
      {/* Pagination would go here */}
    </div>
  );
};

const StokHareketleriTab: FC<{ movements: StockMovement[] }> = ({ movements }) => (
  <div>
    <h2 className="page-header" style={{fontSize: '1.5rem', marginBottom: '24px'}}>Stok Hareket Geçmişi</h2>
    <div className="data-table-container">
      <table className="data-table">
        <thead>
          <tr>
            <th>Tarih</th><th>Ürün Adı</th><th>İşlem Tipi</th><th>Miktar</th><th>Açıklama</th><th>Kullanıcı</th>
          </tr>
        </thead>
        <tbody>
          {movements.length > 0 ? movements.map(m => (
            <tr key={m.id}>
              <td>{new Date(m.date).toLocaleString('tr-TR')}</td>
              <td>{m.productName}</td>
              <td>{m.type}</td>
              <td style={{color: m.quantity > 0 ? 'var(--success-color)' : 'var(--danger-color)'}}>{m.quantity > 0 ? '+' : ''}{m.quantity}</td>
              <td>{m.description}</td>
              <td>{m.user}</td>
            </tr>
          )) : (
            <tr><td colSpan={6}><EmptyState message="Hiç stok hareketi bulunamadı." /></td></tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
);

const FirsatlarTab: FC<{ products: Product[] }> = ({ products }) => {
    const [isLoading, setIsLoading] = useState(false);
    const [analysisResult, setAnalysisResult] = useState<string | null>(null);
    const ai = useMemo(() => new GoogleGenAI({ apiKey: process.env.API_KEY as string }), []);

    const handleAnalyze = async () => {
        setIsLoading(true);
        setAnalysisResult(null);
        try {
            const systemInstruction = "Sen bir e-ticaret şirketi için uzman bir iş analistisin. Sağlanan stok verilerini (JSON formatında) analiz et. Temel fırsatları, riskleri ve önerileri belirle. Örneğin, yavaş hareket eden ürünlere, yakında yeniden sipariş edilmesi gereken ürünlere veya potansiyel paket ürünlere dikkat çek. Bulgularını başlıklar (### Başlık), listeler (* Madde) ve vurgular (**vurgu**) için markdown kullanarak net, eyleme geçirilebilir bir formatta Türkçe olarak sun.";
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash',
                contents: `Stok verileri: ${JSON.stringify(products)}`,
                config: { systemInstruction },
            });
            setAnalysisResult(response.text);
        } catch (error) {
            console.error("AI analysis error:", error);
            setAnalysisResult("Analiz sırasında bir hata oluştu. Lütfen tekrar deneyin.");
        } finally {
            setIsLoading(false);
        }
    };

    return (
        <div className="firsatlar-container">
            <LightbulbIcon className="ai-icon" />
            <h2>AI Fırsat Analizi</h2>
            <p>Stok ve sipariş verilerinizi analiz ederek işinizi büyütecek fırsatları keşfetmek için butona tıklayın.</p>
            <button className="btn btn-primary" onClick={handleAnalyze} disabled={isLoading}>
                {isLoading ? 'Analiz Ediliyor...' : 'Fırsatları Analiz Et'}
            </button>
            {isLoading && <div className="loading-dots" style={{color: 'var(--primary-text-color)', marginTop: '20px'}}><span></span><span></span><span></span></div>}
            {analysisResult && (
                <div className="firsatlar-analysis-result" dangerouslySetInnerHTML={{ __html: analysisResult.replace(/### (.*)/g, '<h3>$1</h3>').replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>').replace(/\* (.*)/g, '<li>$1</li>').replace(/(\<li\>.*\<\/li\>)+/g, '<ul>$&</ul>') }}></div>
            )}
        </div>
    );
};

// --- MAIN COMPONENT ---
const StokYonetimi = ({ action }: { action?: string | null }) => {
  type Tab = 'genelBakis' | 'urunler' | 'stokHareketleri' | 'firsatlar';
  const [activeTab, setActiveTab] = useState<Tab>('genelBakis');
  const [products, setProducts] = useState<Product[]>(initialProducts);
  const [movements, setMovements] = useState<StockMovement[]>(initialMovements);
  const [isModalOpen, setModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  useEffect(() => {
    if (action === 'new_product') {
        handleAddNewProduct();
    }
    if (action === 'view_movements') {
        setActiveTab('stokHareketleri');
    }
  }, [action]);

  const tabs: { id: Tab, label: string }[] = [
    { id: 'genelBakis', label: 'Genel Bakış' },
    { id: 'urunler', label: 'Ürünler' },
    { id: 'stokHareketleri', label: 'Stok Hareketleri' },
    { id: 'firsatlar', label: 'Fırsatlar' }
  ];

  const handleEditProduct = (product: Product) => {
    setEditingProduct(product);
    setModalOpen(true);
  };
  
  const handleAddNewProduct = () => {
      setEditingProduct(null);
      setModalOpen(true);
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case 'genelBakis': return <GenelBakisTab products={products} />;
      case 'urunler': return <UrunlerTab products={products} setProducts={setProducts} handleEdit={handleEditProduct} handleAddNew={handleAddNewProduct} />;
      case 'stokHareketleri': return <StokHareketleriTab movements={movements} />;
      case 'firsatlar': return <FirsatlarTab products={products} />;
      default: return null;
    }
  };

  return (
    <div className="page-container">
      <div className="page-header">
        <h1>Stok Yönetimi</h1>
      </div>
      <div className="tabs">
          {tabs.map(tab => (
            <button
              key={tab.id}
              className={`tab-btn ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >{tab.label}</button>
          ))}
      </div>
      <div className="tab-content">
        {renderTabContent()}
      </div>
      <UrunModal
        isOpen={isModalOpen}
        closeModal={() => setModalOpen(false)}
        setProducts={setProducts}
        productToEdit={editingProduct}
      />
    </div>
  );
};

export default StokYonetimi;